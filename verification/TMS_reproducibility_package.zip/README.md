# TMS Reproducibility Package — Manifest

This package contains every computational verification referenced in *The Triadic
Measurement Substrate* (TMS), the complete two-volume corpus. Each script is
deterministic and standalone: it recomputes a specific structural claim from first
principles and prints the result. Nothing here depends on hidden state or external
data; a reviewer can run any script in isolation.

**Requirements:** Python 3 with `numpy`, `scipy`, and `sympy`. No other
dependencies. Install with `pip install numpy scipy sympy`.

**To run any check:** `python3 <script_name>.py`

Most scripts complete in seconds. Four are compute-heavy and take 30–90 seconds
(noted below with †). `lp1_stage13v3_zoo.py` (an intermediate zoo variant kept
for the audit trail; superseded by v4) can take several minutes on modest hardware.

---

## Volume 1 — substrate, geometry, code, dynamics

| Script | Verifies | Corpus location |
|--------|----------|-----------------|
| `lp1_stage5.py` | FCC level-1 sublattice structure, coordination 12, NN²=8 | Paper 1 §VI; App. E |
| `lp1_stage6.py` | Sublattice bifurcation into two interpenetrating FCC lattices | Paper 5 §6.1; App. E |
| `lp1_stage7.py` | Stabilizer null-space law k = 3·L_box | Paper 1 §V |
| `lp1_stage8.py` | Stabilizer structure at successive box sizes | Paper 1 §V |
| `lp1_stage9.py` | [[4,2,2]] code parameters (logical dim, distance) | Paper 1 §V |
| `lp1_stage9_diagnostic.py` † | Extended stabilizer diagnostics | Paper 1 §V |
| `lp1_stage10.py` | Wave-equation coefficient from FCC signal conservation | Paper 1 §VI |
| `lp1_stage11_stella.py` | Stella-octangula tile geometry, boundary coordinates, L_p = 3√2 ℓ_p extent; CLAIM 5 retains a within-sublattice closure realization as a negative control (it omits the level-2 centroid and correctly fails to cycle) | Paper 5 §6.1; App. E |
| `claim5_corrected.py` | Two-flop T-closure of the minimum program, corpus-described cycle (tile → level-2 centroid → tile): support period exactly 2 in every variant/branch, singular centroid geometrically forced, signed-pattern period 2 in the coherent-surround limit (P2 §6.2 as written) | Paper 5 §6.1.2; App. E; App. B.4 |
| `tms_dynamics.py` | The operational flop operator T (resolution + 1→4 transport) | Paper 2 §IV |
| `spec_verify_T.py` | Specification check of T against the corpus's arithmetic: the four Π_ψ values, both resolution branches, 1→4 transport accounting | Paper 2 §§3.2, 4.1; Paper 1 §§4.2–4.3 |

## Volume 1 — matter sector (spin, mass, chemistry)

| Script | Verifies | Corpus location |
|--------|----------|-----------------|
| `lp1_stage12_b5ranks.py` | B.5 rank structure | Paper 5 App. B |
| `lp1_stage13_zoo.py` … `v4` | Minimum-configuration enumeration (the "zoo"), B.4 count = 4 | Paper 5 App. B |
| `lp1_stage14_spinor.py` | Spinor construction (early route) | Paper 5 §4.1 |
| `lp1_stage15_fermion.py` | Fermion/boson split from node parity | Paper 5 §4.1 |
| `lp1_stage16_mass.py` † | Mass-minimum and standing-program structure | Paper 5 §8.4.3 |
| `lp1_stage17_chemistry.py` | Subshell capacities (2,6,10), Madelung n+ℓ, noble gases to Z=86 | Paper 5 §8.4.7 |
| `lp1_stage18_spinor_threeness.py` | Fermion sign from oddness; SU(2) spin-½ from Born identity | Paper 5 §4.1 (Lemma A) |
| `lp1_stage19_closed_constants.py` | The closed constants (factor of two = 2, geometric ε = 0) | Paper 5 §5.5 |
| `lp1_stage20_mass_spectrum.py` † | Discrete rational amplitude set |Π| ∈ {1, ½, ⅓, 0} | Paper 5 §8.4.3 |

## Volume 1 — this session's derivations (Stages 21–25)

| Script | Verifies | Corpus location |
|--------|----------|-----------------|
| `lp1_stage21_spin_geometry.py` | SO(3) reconstruction from recoupling; 3D embedding (rank 3, with teeth); three = minimal spatial valence; node is faithful SU(2) rep with 2π→−I | Paper 5 §4.1 (Lemma A, Cor. A.0) |
| `lp1_stage22_diagonal_action.py` | Diagonal whole-event SU(2) forced by the flop (S₃ symmetry + axis-free covariance, with teeth) | Paper 5 §4.1 |
| `lp1_stage23_form_invariance.py` | Triadic structure is a fixed point of coarse-graining (identical invariants, levels 0–3) | Paper 3 §4.7 |
| `lp1_stage24_heavy_elements.py` | f = 14 from harmonic angular-mode count; full periodic table to Z=118, lanthanide/actinide blocks | Paper 5 §8.4.7 |
| `lp1_stage25_dispersion.py` | Exact FCC dispersion; isotropic quadratic term; anisotropic quartic remainder (coeff 1/48); [100]<[110]<[111] signature | Paper 5 §4.1 |
| `dispersion_25_magnitude.py` | Lorentz-violation magnitude vs experiment (10⁻⁵⁸ optical … 10⁻¹⁹ GZK) | Paper 5 §4.1 |

## Appendix computations (G, H) and scale accounting

| Script | Verifies | Corpus location |
|--------|----------|-----------------|
| `su3_closure.py` | The 8 transport generators close to exactly su(3); overshoot impossible by construction | App. H |
| `su3_exhaustive.py` | Exhaustive su(3) check: independence, all commutators, trivial center, negative-definite Killing form (eigenvalues −12), rank 2, irreducible fundamental | App. H |
| `hbar_G_scale_accounting.py` | Two intrinsic scales (ℓ_p, τ_flop) → c derived; one import (ℏ) → G derived; {c,ℏ,G} invertible dimension basis | Paper 1 §3.2–3.3 |
| `hbar_G_noncircularity.py` | The scale derivation is a strict DAG (non-circular) | Paper 1 §3.2–3.3 |

## The selection functional (PGE)

| Script | Verifies | Corpus location |
|--------|----------|-----------------|
| `pge_moduli.py` | PGE condition (i) as moduli dimension: sphere = 0 params (unique), triadic enclosure = integer count | Front matter (PGE formal statement) |
| `pge_hcp_test.py` | The FCC-selecting constraint set K derived from Axiom 4 (the contested HCP case) | Paper 1 §2.4 |
| `delta_k_close.py` | The depth-coupling residual δ_k = 1, derived from the form-invariance fixed point (closes the last open coupling item) | Paper (Vol 2) §5.4 |

## Adversarial review scripts

These scripts document hostile-review passes against the corpus's own claims —
challenges raised by independent LLM reviewers (DeepSeek, Grok) and resolved
honestly in-session, including downgrades where a claim did not survive scrutiny.
Kept as the audit trail, not as supplementary polish.

| Script | Addresses |
|--------|-----------|
| `chiral_index.py` | First (retracted) attempt at a net chirality argument |
| `chirality_circularity_check.py` | Tests whether the chirality argument is circular (DeepSeek obj. 2) |
| `nn_chirality_test.py` | Whether R-hat irreversibility closes the Nielsen-Ninomiya chirality gap |
| `coherence_gate.py` | Corrects the per-level consolidation gate to quantized-per-level / continuous-in-aggregate |
| `gate_forced.py` | Tests whether the threshold-nucleation gate is forced by the axioms |
| `gate_forcing_check.py` | DeepSeek objection 3 (KJMA gate retrofit) — downgrades Derived to Derived-conditional |
| `gate_flop_indivisibility.py` | Resolves the n=3 KJMA exponent via flop indivisibility, not handedness |
| `deltak_and_desi_check.py` | DeepSeek objections 1 (delta_k tautology) and 4 (DESI concordance inflation) |
| `grok_check.py` | Cross-checks Grok's four objections against fixes already made in response to DeepSeek |
| `normpres_G.py` | Norm-preservation checks (App. G) underlying the su(3) closure result |

## Independent integrity audits

| Script | Verifies |
|--------|----------|
| `arithmetic_audit.py` | 18 independent recomputations of core numerical claims across the whole corpus |
| `dependency_scan.py` | No forward-references; Paper 11 traces to Paper 1; no circularity |
| `label_integrity.py` | No ℏ/G/c/α overreach; no undisclaimed dimensionful-value claims |
| `consistency_check.py` | No contradictory multiply-stated quantities |

---

## Notes

- **†** = compute-heavy (30–90 s). All others run in seconds.
- Every script prints its own verdict. The audit scripts print a pass/fail summary.
- The `v2`/`v3`/`v4` variants of `lp1_stage13` are successive refinements of the
  configuration enumeration; the final (`v4`) is the one the corpus count reflects.
- Scripts are named to match their references in the corpus text and appendices,
  so any "reproducible (`script_name`)" note in the paper resolves to a file here.

## Honest scope of these checks

These scripts verify that the framework's mathematical claims are internally
correct and self-consistent — that the numbers are what the corpus says, the
groups close, the structures recur, the dispersion is as computed. They are
verification of the mathematics, not evidence that the physical interpretation is
correct. That distinction is maintained throughout the corpus and applies here.

## Dark-sector exploration scripts (supplementary, exploratory)

These scripts accompany the dark-energy section (Vol 2) and the DESI DR2
structural-concordance discussion. They are **exploratory**, not derivations: they
demonstrate the qualitative mechanism (dynamical dark energy, phantom-to-quintessence
crossing, dark-sector channel exchange) and its input-dependence. The corpus marks
the quantitative w(z) as the sector's principal open problem; these scripts show
exactly why (the crossing is reproduced for a range of inputs, not universally).

| Script | Shows |
|--------|-------|
| `eos_sim.py` | Forward equation-of-state simulation; derived limiting signs (w=-1 excluded), crossing is input-dependent |
| `dark_sector_v5.py` | Dark sector built on the corpus's own formation/exhaustion equations; pre-registered P1-P5 pass, P6 (quantitative DESI timing) open |

These are provided for transparency about what the mechanism does and does not yet
establish. They do not enter any Derived claim.

---

# README ADDENDUM — for v1.0 DOI release

## The two dark-sector scripts answer different questions (read this before running them)

`eos_sim.py` and `dark_sector_v5.py` return different verdicts on the w = −1 crossing,
and this is documented behaviour, not a discrepancy to be resolved by preferring one.

**`eos_sim.py`** is a forward simulation from first-principles corpus inputs with no
freedom beyond the corpus's own area/volume dilution factor. It does **not** produce a
crossing (v1: w pinned near −1.5; v2, with the volume-dilution correction identified
independently of the desired answer: still no crossing). Its own output states the
honest conclusion, which this README repeats: **the crossing is asserted as a
qualitative mechanism in the corpus and is not yet reproduced by a
minimal-input forward simulation.**

**`dark_sector_v5.py`** is a mechanism demonstration over a parameter sweep. It shows
the phantom→quintessence crossing is **robust in direction** (present in 9/9 parameter
combinations, early w ≈ −1.06 → late w ≈ −0.98, below→above) but **wrong in timing at
default inputs** (crossing z ≈ 7.3 vs the DESI-hinted z ~ 0.3–0.5). This is the
"quantitative timing is input-dependent" statement of Volume 2 Paper 1, made executable.

Together the two scripts bound the claim exactly as the corpus labels it:
- **Derived / robust:** w = −1 exact is excluded; the equation of state is dynamical;
  the crossing direction is phantom→quintessence. (Sharp falsifier: a future
  measurement pinning w(z) = −1 constant kills the mechanism.)
- **Open:** the crossing redshift. It depends on the level-advance schedule k(a),
  which the corpus does not yet derive. Deriving k(a) from the T_p ratio of 6 per
  level is the identified next computation; until then, no timing is claimed.

`desi_headtohead.py` reports the one untuned point of contact:
w(0.5) ≈ −1.02 vs DESI DR2's −1.024 ± 0.043 (0.09σ). One point, claimed as one point.

## Running the audit scripts

`consistency_check.py`, `dependency_scan.py`, and `label_integrity.py` locate the
corpus in this order: (1) a path given as the first command-line argument, (2)
`TMS_Complete_Corpus.tex` beside the script, (3) the current directory. Example:

    python3 consistency_check.py /path/to/TMS_Complete_Corpus.tex

## Known issues

None. The noble-gas derivation runs to Z = 118 in the corpus (Paper 5 §8.4.7,
verified by `lp1_stage24_heavy_elements.py`); `lp1_stage17_chemistry.py` verifies the
lighter table to Z = 86 as its stated scope. Earlier draft notes listing queued issues
were verified stale before this release.

## v1.0 final revisions (2026-07-07)

Applied before mint, all verified by recompile (zero errors, zero undefined
references) and the audit trio (all exit 0):

1. **T-closure verification completed.** The shipped `lp1_stage11_stella.py`
   CLAIM 5 had an initialization bug (the all-odd tile was filtered against the
   all-even patch, emptying the configuration). Fixed; the faithful two-stratum
   test was added as `claim5_corrected.py`. Result: the corpus's two-flop cycle
   is confirmed as stated, with the singular centroid geometrically forced.
   Corpus §6.1.2, §6.2, Appendix E, and Appendix B.4 were updated to the exact
   verified statements, and the §6.2 construction paragraph now distinguishes
   the isolated 2-flop closure floor from the operative coupling period
   T_p^(1) = 6 t_p.
2. **Seal theorems restated in determination form.** The inward seal (P10
   App. B) and exterior-unreadability (P11 App. B.4) previously concluded zero
   mutual information from non-determination premises; both are now stated and
   proved in the same determination grammar as the outward seal ("the reading
   leaves the quantity unfixed"), with the inward-seal proof grounded in the
   strictly positive form-surplus (RICHNESS, R = 2 bits). No downstream result
   consumed the stronger form; unrankability, self-report gameability, and
   standing are unchanged.
3. **Glossary of Terms added** (75 entries, corpus back matter, before the
   afterword).

## Audit-script precision fixes in the 2026-07-06 release

Three earlier `[CONFLICT]`/`[REVIEW]` flags were false positives of the audit
scripts' own pattern matching, not corpus issues, and the scripts were corrected:

1. `consistency_check.py` flagged `c_TMS = 1/√2` as conflicting. All flagged
   instances were correct statements of the constant (the detector's exclusion
   pattern re-matched them) or the documented saturation-bound inversion
   `c_TMS = (√2)^k · c_measured` (V2 P5 §3). The detector now classifies the
   right-hand side of every `c_TMS =` statement explicitly, and was verified to
   still catch injected genuine conflicts. It also now exits nonzero on any
   conflict rather than printing a clean-bill footer unconditionally.
2. `label_integrity.py` flagged "Deriving the periodic table's skeleton as
   counting... a more honest claim than deriving ``chemistry'' outright" — the
   corpus sentence that *rejects* the overclaim — as an instance of the
   overclaim. No bare "derives chemistry" claim exists in the corpus. It also
   flagged "the derivation of ℏ and G ... deferred", where "deferred" is the
   disclaimer; "defer" is now in the disclaimer vocabulary.
3. `dependency_scan.py` paper-boundary anchors were hardcoded line numbers,
   misaligned with the consolidated corpus (segments printed as "P?"). Anchors
   are now parsed from the corpus's own structural markers, so the scan stays
   aligned through any regeneration; the forward-reference check was tightened
   so that declared forward pointers (the corpus's build order) are not
   flagged as forward dependencies.
