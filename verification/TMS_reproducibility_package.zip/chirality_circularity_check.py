#!/usr/bin/env python3
"""
DeepSeek's objection 2: the chirality argument is circular. It says Corollary A.0
("one orientation invariant") is just a restatement of "the substrate is globally
chiral," so using A.0 to escape Nielsen-Ninomiya is assuming the conclusion.

Is this fair? The honest test: WHAT does Corollary A.0 actually assert, and was it
derived INDEPENDENTLY of any chirality claim, or does its derivation already
assume net chirality?

If A.0 was derived from something that has nothing to do with fermion doubling
(e.g. pure geometry of the triad), then using it is legitimate -- it's an
independent geometric fact that happens to violate NN's premise. If A.0's
derivation secretly assumes chirality, DeepSeek is right and it's circular.

Let me trace what A.0 / Lemma A actually rest on.
"""
print("="*70)
print("Is Corollary A.0 independent of the chirality claim, or circular?")
print("="*70)
print("""
WHAT A.0 SAYS: the confirmation triad B=3alpha has exactly ONE orientation
invariant -- the sign of the triple product S1.(S2 x S3) of the three agent
spinors. This is the Penrose spin-geometry / SU(2) recoupling result (Stage 21).

WHAT IT RESTS ON (trace the dependency):
  - Three agents enclosing one bit (B=3alpha) -- the founding primitive.
  - The SU(2) structure of the agent polarization (Lemma A, from the [[4,2,2]]
    stabilizer recoupling -- Penrose 1971 spin-geometry theorem).
  - The triple product of three vectors in 3D has ONE sign (orientation) -- this
    is elementary linear algebra: det of a 3x3 matrix is a single scalar whose
    sign is the orientation.

CRITICAL QUESTION: does ANY step here mention fermions, chirality, handedness of
WEAK interactions, or net chiral charge? 

NO. A.0 is a statement about the ORIENTATION of a geometric triad -- the sign of a
triple product. It is derived from the SU(2) recoupling geometry, which comes from
the error-detecting code structure, which comes from B=3alpha. NONE of that
derivation references fermion doubling, the Standard Model chirality, or net
chiral charge.

SO: is 'the triad has one orientation' the SAME as 'the substrate is globally
chiral'? DeepSeek claims they're identical (hence circular). Are they?

  'One orientation invariant' = the triad's handedness is a well-defined single
    sign (like: all triangles in the lattice wind the same way). This is a
    GEOMETRIC fact about the lattice.
  'The substrate is globally chiral' (in the PARTICLE-PHYSICS sense DeepSeek
    means) = the fermion spectrum has net nonzero chiral charge (L != R count).

These are NOT the same statement. One is about lattice geometry (triangle
winding); the other is about the fermion spectrum (mode counting). The chirality
ARGUMENT is precisely the claim that the FIRST (geometric, from A.0) IMPLIES the
SECOND (spectral). That's an inference, not an identity.
""")
print("="*70)
print("VERDICT on DeepSeek objection 2")
print("="*70)
print("""
DeepSeek is PARTLY right and PARTLY wrong, and the distinction matters:

WRONG part: A.0 is NOT circular in its DERIVATION. It is derived from triad
geometry (triple-product sign) via the Penrose/SU(2) recoupling, with zero
reference to fermion chirality. So invoking it is not 'assuming the conclusion' --
it's an independently-derived geometric fact.

RIGHT part (and this is the real hit): the INFERENCE from 'geometric single
orientation (A.0)' to 'net fermion chiral charge != 0' is NOT rigorously
established by the corpus. DeepSeek is correct that we assert the geometric
one-handedness defeats NN, but we do NOT show explicitly that the geometric
orientation translates into a spectral net-index via the actual lattice Dirac
operator. That step -- geometry => spectrum -- is exactly the overlap-operator
index computation the corpus ALREADY admits is open (the 'magnitude' we said was
not derived).

SO THE HONEST STATUS: the corpus does NOT claim to have derived the net index (it
explicitly leaves magnitude open). But DeepSeek is right that even the
EXISTENCE+SIGN claim leans on geometry=>spectrum, which is not fully shown. The
current text may state existence+sign slightly too strongly. The fix: soften from
'existence and sign are derived' to 'the geometric obstruction to NN cancellation
is identified (A.0 breaks the handedness-symmetric premise); whether this produces
a nonzero SPECTRAL index, and its sign, requires the lattice Dirac computation and
is not established here.' That is the honest calibration.
""")
