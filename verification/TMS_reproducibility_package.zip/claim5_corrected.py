#!/usr/bin/env python3
"""
CLAIM 5 CORRECTED — the 2-flop T-closure on the stella-octangula tile.

The shipped lp1_stage11_stella.py CLAIM 5 had an initialization bug: the tile
(all-odd sites) was filtered against the all-even FCC patch, so the closure
test ran on an EMPTY configuration (confirmed-count [0,0,0,0,0], trivial
period 1). This script runs the real test.

The corpus's own description of the cycle (P5 §6.1.2, T-closure bullet):
  flop 1: confirms a bit at the level-2 centroid p=(2,2,2)
  flop 2: re-distributes confirmation across the eight level-1 tile sites
So the dynamics live on TWO strata — level-1 (all-odd) tile vertices and
level-2 (all-even, sum≡2 mod 4) centroids — coupled by tetrahedral adjacency
(squared distance 3). We implement exactly that alternation and report:
  (i)  closure period of the confirmed SUPPORT (which sites are confirmed)
  (ii) closure period of the SIGNED pattern (support + chi values)
for both resolution branches, plus the strict/localized variant where only
centroids fully interior to the tile can fire (the corpus names ONE centroid).

Honest reporting: no hard-pass. The numbers are the finding.
"""
import itertools
import numpy as np
from tms_dynamics import resolve

def sqdist(a, b):
    return sum((a[i]-b[i])**2 for i in range(3))

def all_odd(s):
    return all(c % 2 == 1 for c in s)

def coord_sum_mod4(s):
    return (s[0]+s[1]+s[2]) % 4

# ---------------------------------------------------------------- geometry
def build_tile():
    p = (2, 2, 2)
    candidates = [(i, j, k) for i in (1, 3) for j in (1, 3) for k in (1, 3)]
    A_tet = [s for s in candidates if coord_sum_mod4(s) == 1]
    B_tet = [s for s in candidates if coord_sum_mod4(s) == 3]
    return p, A_tet, B_tet

def domain(lo=-3, hi=7):
    """Two strata: level-1 all-odd sites; level-2 all-even sum≡2 mod4 sites."""
    rng3 = range(lo, hi)
    lvl1 = [(i, j, k) for i in rng3 for j in rng3 for k in rng3
            if all_odd((i, j, k))]
    lvl2 = [(i, j, k) for i in rng3 for j in rng3 for k in rng3
            if all(c % 2 == 0 for c in (i, j, k)) and coord_sum_mod4((i, j, k)) == 2]
    return lvl1, lvl2

def tet_adjacency(lvl1, lvl2):
    """Tetrahedral adjacency: level-2 site <-> level-1 sites at sq-dist 3."""
    l1s, l2s = set(lvl1), set(lvl2)
    up = {}    # level-2 site -> its level-1 tetra vertices (parents on flop 1)
    down = {}  # level-1 site -> its adjacent level-2 centroids (parents on flop 2)
    for c in lvl2:
        up[c] = [v for v in lvl1 if sqdist(c, v) == 3]
    for v in lvl1:
        down[v] = [c for c in lvl2 if sqdist(c, v) == 3]
    return up, down

# ---------------------------------------------------------------- dynamics
def flop_up(chi, lvl2, up, branch, rng, min_parents=3):
    """Level-1 confirmed -> confirm level-2 centroids (corpus flop 1)."""
    new = {}
    for c in lvl2:
        parents = [chi[v] for v in up[c] if v in chi]
        if len(parents) < min_parents:
            continue
        pi = sum(parents) / len(parents)
        new[c] = resolve(pi, branch, rng)
    return new

def flop_down(chi, lvl1, down, branch, rng, min_parents=1):
    """Level-2 confirmed -> re-distribute over level-1 sites (corpus flop 2)."""
    new = {}
    for v in lvl1:
        parents = [chi[c] for c in down[v] if c in chi]
        if len(parents) < min_parents:
            continue
        pi = sum(parents) / len(parents)
        new[v] = resolve(pi, branch, rng)
    return new

def signature(chi):
    pts = sorted(chi)
    if not pts:
        return frozenset()
    mn = (min(p[0] for p in pts), min(p[1] for p in pts), min(p[2] for p in pts))
    return frozenset(((p[0]-mn[0], p[1]-mn[1], p[2]-mn[2]), chi[p]) for p in pts)

def support_sig(chi):
    pts = sorted(chi)
    if not pts:
        return frozenset()
    mn = (min(p[0] for p in pts), min(p[1] for p in pts), min(p[2] for p in pts))
    return frozenset((p[0]-mn[0], p[1]-mn[1], p[2]-mn[2]) for p in pts)

def run(variant, branch, n_flops=6, seed=2):
    p, A_tet, B_tet = build_tile()
    lvl1, lvl2 = domain()
    up, down = tet_adjacency(lvl1, lvl2)
    rng = np.random.default_rng(seed)

    if variant == "interior-only":
        # corpus names ONE centroid: restrict flop-1 firing to centroids all
        # of whose tetra vertices are confirmed (fully interior) -> only p
        min_up = 4
    else:  # "open" : any centroid with >=3 confirmed tetra vertices fires
        min_up = 3

    chi = {**{s: 1 for s in A_tet}, **{s: -1 for s in B_tet}}
    hist = [dict(chi)]
    for t in range(n_flops):
        if t % 2 == 0:
            chi = flop_up(chi, lvl2, up, branch, rng, min_parents=min_up)
        else:
            chi = flop_down(chi, lvl1, down, branch, rng, min_parents=1)
        hist.append(dict(chi))

    sizes = [len(h) for h in hist]
    # closure periods against t=0 (even steps only compare like strata)
    per_signed = next((n for n in range(1, len(hist))
                       if signature(hist[n]) == signature(hist[0])), None)
    per_support = next((n for n in range(1, len(hist))
                        if support_sig(hist[n]) == support_sig(hist[0])), None)
    return sizes, per_support, per_signed, hist

if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("=" * 68)
    print("CLAIM 5 CORRECTED — 2-flop T-closure, corpus-described cycle")
    print("(tile -> level-2 centroid -> tile; tetrahedral adjacency)")
    print("=" * 68)
    p, A_tet, B_tet = build_tile()
    print(f"tile: A-tet={sorted(A_tet)} (+1), B-tet={sorted(B_tet)} (-1), "
          f"centroid p={p}\n")

    for variant in ("interior-only", "open"):
        print(f"--- variant: {variant} "
              f"({'only fully-interior centroid fires' if variant=='interior-only' else 'any >=3-parent centroid fires'}) ---")
        for branch in ("deterministic", "probabilistic"):
            sizes, ps, pg, hist = run(variant, branch)
            print(f"  {branch:>14}: confirmed-count/flop = {sizes}")
            print(f"  {'':>14}  support closure period = {ps}, "
                  f"signed-pattern closure period = {pg}")
            # show flop-1 detail for the interior-only case
            if variant == "interior-only" and branch == "deterministic":
                h1 = hist[1]
                print(f"  {'':>14}  flop-1 confirmed: {sorted(h1)} "
                      f"values={[h1[s] for s in sorted(h1)]}")
                h2 = hist[2]
                print(f"  {'':>14}  flop-2 confirmed support size: {len(h2)} "
                      f"(tile has 8)")
        print()
    print("Honest note: Pi at the centroid over the full inversion-ground tile")
    print("is (4*(+1)+4*(-1))/8 = 0 -> the confirmed BIT VALUE at p is a fair")
    print("U_sh coin (exactly the corpus's zero-bias rule). Any signed-pattern")
    print("closure therefore depends on whether flop 2 re-imprints the A/B")
    print("antisymmetry, which one scalar bit at p cannot carry by itself.")
    print("The SUPPORT-level cycle (tile -> centroid -> tile) is the testable")
    print("form of the corpus's claim; the numbers above are the finding.")


# ----------------------------------------------------------------------
# VARIANT 3: clamped coherent surround (the P2 §6.2 definition's limit)
# ----------------------------------------------------------------------
def run_with_surround(branch, n_flops=6, seed=2):
    """Boundary sites (the 9 out-of-tile in-sublattice NN of each vertex)
    are clamped at the sublattice ground (A:+1, B:-1) — the 'large coherent
    surround' limit of the P2 §6.2 program definition, maintained by the
    stabilizer repair of P2 §5.2. Tile + centroid evolve freely."""
    p, A_tet, B_tet = build_tile()
    lvl1, lvl2 = domain()
    up, down = tet_adjacency(lvl1, lvl2)
    rng = np.random.default_rng(seed)

    tile = set(A_tet) | set(B_tet)
    # boundary: in-sublattice NN (sq-dist 8, same mod-4 class) of tile, outside it
    def sub_nn(v):
        return [n for n in lvl1 if sqdist(v, n) == 8
                and coord_sum_mod4(n) == coord_sum_mod4(v)]
    boundary = {}
    for v in tile:
        for n in sub_nn(v):
            if n not in tile:
                boundary[n] = 1 if coord_sum_mod4(n) == 1 else -1

    chi = {**{s: 1 for s in A_tet}, **{s: -1 for s in B_tet}}
    hist = [dict(chi)]
    for t in range(n_flops):
        if t % 2 == 0:
            # flop 1: centroids fire from tile vertices (interior-only)
            chi = flop_up(chi, lvl2, up, branch, rng, min_parents=4)
        else:
            # flop 2: tile vertices fire from confirmed centroids + clamped
            # surround (within-sublattice channel)
            new = {}
            for v in tile:
                parents = [chi[c] for c in down[v] if c in chi]
                parents += [boundary[n] for n in sub_nn(v) if n in boundary]
                if not parents:
                    continue
                pi = sum(parents) / len(parents)
                new[v] = resolve(pi, branch, rng)
            chi = new
        hist.append(dict(chi))

    sizes = [len(h) for h in hist]
    per_signed = next((n for n in range(1, len(hist))
                       if signature(hist[n]) == signature(hist[0])), None)
    per_support = next((n for n in range(1, len(hist))
                        if support_sig(hist[n]) == support_sig(hist[0])), None)
    return sizes, per_support, per_signed, hist, len(boundary)

print("\n" + "=" * 68)
print("VARIANT 3 — clamped coherent surround (P2 §6.2 limit; P3 §2.2 repair)")
print("=" * 68)
for branch in ("deterministic", "probabilistic"):
    sizes, ps, pg, hist, nb = run_with_surround(branch)
    print(f"  {branch:>14}: boundary sites clamped = {nb}")
    print(f"  {'':>14}  confirmed-count/flop = {sizes}")
    print(f"  {'':>14}  support closure period = {ps}, "
          f"signed-pattern closure period = {pg}")
    h2 = hist[2]
    restored = all(h2.get(s) == (1 if coord_sum_mod4(s) == 1 else -1)
                   for s in hist[0])
    print(f"  {'':>14}  A/B ground values restored at flop 2: {restored}")
