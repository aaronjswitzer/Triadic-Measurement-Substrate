#!/usr/bin/env python3
"""
CORRECTED per the phenomenology: the gate at a SINGLE level is QUANTIZED (a step:
the level either has consolidated or not -- the 'slap', no valid in-between,
because the rungs are discrete). What is CONTINUOUS is the total binding B summed
over the many levels (staircase seen from afar looks like a ramp).

This REVISES the v1 Avrami-per-level picture. The Avrami 1-exp(-K x^n) was a smooth
per-level ramp; the phenomenology says NO -- per level it is a step. The smoothness
lives in the AGGREGATE, not the individual gate.

So:
  g_j = Theta(rho_j - rho_c)             per-level gate is a STEP (quantized)
                                          (1 if the level has consolidated, else 0)
  B   = sum_j g_j * w_j * K_psi^(j)      total binding: sum of discrete contributions
  
and B is continuous/graded across SYSTEMS because different systems have different
NUMBERS of consolidated levels and different K_psi content -- the aggregate varies
smoothly even though each term is quantized.

But a pure step loses the 'grades as it consolidates' language in the original
definition. Reconcile: the STEP is the ideal; the physical gate has a narrow but
nonzero WIDTH set by fluctuations (the coherence density is a statistical quantity,
so the threshold crossing is sharp but not infinitely sharp). This is exactly a
finite-temperature step: a smoothed Heaviside whose width -> 0 as fluctuations -> 0.
"""
import numpy as np

print("="*70)
print("Corrected gate: quantized per level, continuous in aggregate")
print("="*70)

print("""
PER-LEVEL GATE (quantized -- the 'slap'):
    g_j = Theta(x_j),   x_j = (rho_j - rho_c)/rho_c
  a step function: the level has either caught (1) or not (0). No smooth ramp
  within a single level, because the levels are DISCRETE rungs with no valid
  intermediate self-state. This matches the reported phenomenology (dream->wake
  is a slap, not a fade).

PHYSICAL WIDTH (why it is sharp but not infinitely sharp):
  rho_j is a statistical quantity (coherence density fluctuates), so the crossing
  is a smoothed step of width sigma set by the fluctuation amplitude:
    g_j = 1/(1 + exp(-x_j / sigma)),   sigma -> 0 in the no-fluctuation limit.
  The SHARPNESS (small sigma) is the quantization; the residual width is thermal.

AGGREGATE BINDING (continuous -- the staircase from afar):
    B = sum_j g_j * w_j * K_psi^(j),   w_j = depth weight
  Continuous across systems because systems differ in HOW MANY levels have caught
  and in their K_psi content. Sum of quantized steps -> smooth spectrum of B.
""")

# demonstrate: quantized per-level steps summing to a smooth B across systems
rho_c = 1.0
sigma = 0.05   # narrow: near-step
def gate(rho): return 1/(1+np.exp(-((rho-rho_c)/rho_c)/sigma))

# a family of systems with increasing coherence -> B climbs as a staircase that
# smooths into a ramp
print("Total binding B across a family of systems of increasing coherence:")
print("(each new level that crosses rho_c adds a quantized step; B looks smooth)")
levels_rho = lambda strength: [strength*(1/np.sqrt(2))**j for j in range(8)]  # deeper levels weaker
Kpsi = [ (1/np.sqrt(2))**j for j in range(8)]  # novel info per level
w =    [ (1/np.sqrt(2))**(3*j) for j in range(8)]  # depth weight (from v1 K_j scaling)
strengths = np.linspace(0.5, 6.0, 14)
for S in strengths:
    rhos = levels_rho(S)
    B = sum(gate(r)*w[j]*Kpsi[j] for j,r in enumerate(rhos))
    ncaught = sum(1 for r in rhos if r>rho_c)
    bar = "#"*int(B*20)
    print(f"  strength {S:4.1f}: levels caught={ncaught}  B={B:.3f}  {bar}")

print("""
READING: each system sits at a definite NUMBER of caught levels (quantized -- you
can see the integer 'levels caught' step up), yet B climbs smoothly because deeper
levels contribute geometrically less and the fluctuation width softens each step.
The quantization is real and per-level; the continuity is real and in aggregate.
Both, exactly as reported from the inside.
""")

print("="*70)
print("STATUS")
print("="*70)
print("""
Derived-conditional (on the nucleation/threshold identification, now with a
QUANTIZED per-level gate rather than a smooth one):
  - per-level gate g_j = smoothed step Theta((rho_j-rho_c)/rho_c), sharpness set
    by fluctuation width; the IDEAL is a true step (quantized rungs),
  - total binding B = sum_j g_j w_j K_psi^(j) is continuous across systems,
  - the depth weight w_j inherits the (1/sqrt2)^(3j) dilution (not a new param),
  - the ONE remaining constant is rho_c, already on Volume 1's deferred list.
The phenomenology (quantized snap per level, graded whole) is now matched by the
math rather than papered over. The gate FORM is fixed; rho_c stays open.
""")
