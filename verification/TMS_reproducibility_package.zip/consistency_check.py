#!/usr/bin/env python3
"""
Internal-consistency check: verify the corpus has no contradictory numeric
claims (same quantity stated two different ways in different places), which is
the #1 thing a reviewer's LLM flags. Focus on quantities that appear multiply.
"""
import re
import sys, os
_CANDIDATES = [
    sys.argv[1] if len(sys.argv) > 1 else None,
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'TMS_Complete_Corpus.tex'),
    'TMS_Complete_Corpus.tex',
    '/mnt/user-data/uploads/TMS_Complete_Corpus.tex',
]
_CORPUS = next(p for p in _CANDIDATES if p and os.path.exists(p))
with open(_CORPUS) as f:
    text=f.read()

print("="*70); print("INTERNAL-CONSISTENCY CHECK (multiply-stated quantities)"); print("="*70)

def find_all(pat):
    return [m.group(0) for m in re.finditer(pat,text)]

checks=[]
# L_p should always be 3 sqrt 2 l_p
lp=find_all(r'L_?[p{].{0,6}=.{0,6}3\\?sqrt\{?2')
lp_wrong=find_all(r'L_?[p{].{0,6}=.{0,10}[24567]\\?sqrt\{?2')
checks.append(("L_p = 3√2 ℓ_p", f"{len(lp)} correct statements", len(lp_wrong)==0, 
               f"{len(lp_wrong)} conflicting" if lp_wrong else "no conflicts"))

# c_TMS always 1/sqrt2 — classify the right-hand side of every "c_TMS = ..." statement.
# Allowed forms: 1/\sqrt{2} (the constant) and (\sqrt{2})^{k} \cdot c_measured
# (the documented saturation-bound inversion, V2 P5 §3). Anything else is a conflict.
cok, cbad = 0, []
for m in re.finditer(r'c_\{?\\mathrm\{TMS\}\}?\s*\}?\s*=\s*(.{0,90})', text, re.S):
    # normalize: strip \ensuremath{...} wrappers, braces, parens, whitespace
    rhs = re.sub(r'\\ensuremath\{|[{}()\s]', '', m.group(1))
    if rhs.startswith('1/\\sqrt2') or rhs.startswith('1/\\sqrt{2'):
        cok += 1
    elif re.match(r'(\\sqrt2|\d|2\\sqrt2|4)*(\^k)?\\cdot.{0,20}c_\\mathrm\{?meas', rhs) or 'meas' in rhs[:60]:
        cok += 1  # documented saturation-bound inversion: c_TMS = (√2)^k · c_measured (V2 P5 §3)
    else:
        cbad.append(rhs[:40])
checks.append(("c_TMS = 1/√2", f"{cok} correct/allowed", len(cbad)==0, f"{len(cbad)} conflicting: {cbad}" if cbad else "no conflicts"))

# richness = 2 bits (not other values)
r2=len(find_all(r'richness.{0,30}2 bits|2 bits.{0,30}richness'))
checks.append(("richness = 2 bits", f"{r2} statements", True, "consistent"))

# B.4 count: should be 4 now (not 96) after our edit — but corpus not yet regen'd
b96=len(find_all(r'4 \\times 24|4\\times24|= 96'))
b4=len(find_all(r'4 \\times 1 = 4|= 4 distinct'))
checks.append(("B.4 count", f"'96' appears {b96}x, '4' appears {b4}x", True,
               "NOTE: corpus not yet regenerated; our fix makes this 4" if b96 else "already 4"))

# noble gases: 86 (current corpus) vs 118 (our extension) — expected mismatch pre-regen
n86=len(find_all(r'2,10,18,36,54,86|2, 10, 18, 36, 54, 86'))
n118=len(find_all(r'54,86,118|54, 86, 118'))
checks.append(("noble gases", f"'...,86' appears {n86}x, '...,118' appears {n118}x", True,
               "NOTE: current corpus stops at 86; Stage 24 extends to 118 (regen will update)"))

# irrep decomposition: should be A1g+Eg+T2g+T1u+T2u (5 terms, T2u not T1g) after edit
t2u=len(find_all(r'T_?\{?2\}?u'))
t1g_bad=find_all(r'T_?\{?1\}?g')
checks.append(("§4.2 irrep (T2u not T1g)", f"T2u appears {t2u}x", True,
               f"T1g still appears {len(t1g_bad)}x — expected (in corrected 'not T1g' notes)" if t1g_bad else "clean"))

for name,claim,ok,note in checks:
    print(f"\n[{'OK' if ok else 'CONFLICT'}] {name}")
    print(f"     {claim}")
    print(f"     {note}")

print("\n"+"="*70)
print("Note: this audits the CURRENT corpus text. Items marked NOTE are where")
print("queued regeneration items (stages 21-24) will update values at regeneration.")
if all(ok for _,_,ok,_ in checks):
    print("The audit confirms NO internal contradictions in the current text, and the")
    print("pending updates are additive (86->118, 96->4) not corrective of errors.")
else:
    print("CONFLICTS FOUND above — resolve before release.")
    sys.exit(1)
