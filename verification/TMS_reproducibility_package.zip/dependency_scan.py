#!/usr/bin/env python3
"""
Dependency-chain audit: does Paper 11 trace to Paper 1? Scan every paper's
back-references and flag (a) claims labeled Derived with no supporting
cross-ref or sim, (b) forward-references (a paper depending on a LATER paper -
a circularity risk), (c) 'asserted' language that should be derived.
"""
import re

import sys, os
_CANDIDATES = [
    sys.argv[1] if len(sys.argv) > 1 else None,
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'TMS_Complete_Corpus.tex'),
    'TMS_Complete_Corpus.tex',
    '/mnt/user-data/uploads/TMS_Complete_Corpus.tex',
]
_CORPUS = next(p for p in _CANDIDATES if p and os.path.exists(p))
with open(_CORPUS) as f:
    lines=f.readlines()

# paper boundaries (real numbering: V1 P1-5, then V2 = P6-11 but .tex labels them P1-11 second run)
# Paper boundaries are parsed from the corpus's own structural markers
# ("% ---------------- Volume N / name ----------------"), so the scan stays
# aligned with the text through any regeneration. Falls back to nothing-found
# with a clear message rather than mislabeled segments.
bounds=[]
_marker=re.compile(r'^%\s*-{4,}\s*Volume\s*(\d)\s*/\s*(\S+)\s*-{4,}')
for _i,_l in enumerate(lines,1):
    _m=_marker.match(_l)
    if _m:
        bounds.append((_i, f"V{_m.group(1)}-{_m.group(2)}"))
if not bounds:
    print("WARNING: no structural markers found; connectivity scan skipped."); sys.exit(1)

def paper_of(ln):
    p='front'
    for b,name in bounds:
        if ln>=b: p=name
    return p

# scan for forward references: "Paper N" citations where N is a later paper.
# Build the actual reading order by line; a reference to a paper that begins at a
# HIGHER line than the current position AND is cited as established = forward dep.
fwd_refs=[]
paper_ref=re.compile(r'Paper~?(\d+)')
# map paper number -> first line, from the parsed structural markers.
# In the combined file, "Paper N" in V2 refers to V2's own numbering. We check
# within-volume ordering only (the real dependency question).
_v2_bounds=[(b,name) for b,name in bounds if name.startswith('V2-P')]
v2_start=min((b for b,_ in _v2_bounds), default=len(lines)+1)
targets={}
for b,name in _v2_bounds:
    _m=re.match(r'V2-P(\d+)',name)
    if _m: targets[int(_m.group(1))]=b
for i,line in enumerate(lines):
    ln=i+1
    for m in paper_ref.finditer(line):
        n=int(m.group(1))
        # flag references to later papers appearing BEFORE those papers start, only within V2
        if ln>=v2_start:
            if n in targets and ln<targets[n]-50:
                # a reference to a later paper AS ESTABLISHED — the establishment
                # verb must attach to the citation itself ("derived in Paper~N",
                # "Paper~N established/showed"), not merely co-occur on the line.
                # Forward POINTERS ("Paper~N makes X computable", "banked for
                # Paper~N") are the corpus's declared build order, not violations.
                w=line[max(0,m.start()-45):min(len(line),m.end()+45)]
                if re.search(r'(established|derived|shown|proved)\s+in\s+Paper~?\d+|Paper~?\d+\s+(established|derives?d?|showed|proved)\b',w):
                    fwd_refs.append((ln,n,line.strip()[:80]))

print("="*70); print("DEPENDENCY-CHAIN AUDIT"); print("="*70)

print(f"\n1. FORWARD-REFERENCE CHECK (paper citing a later paper as established):")
if fwd_refs:
    for ln,n,ctx in fwd_refs[:15]:
        print(f"   line {ln}: cites Paper {n} as established -> {ctx}")
else:
    print("   none found — no paper depends on a later paper as established. GOOD.")

# scan for 'asserted' / 'we assume' / 'posit' near Derived claims (label risk)
print(f"\n2. ASSERTION-LANGUAGE NEAR DERIVED CLAIMS (label-integrity risk):")
risk_words=re.compile(r'\b(we assume|is assumed|we posit|posited|by assumption|take as given|stipulate)\b',re.I)
hits=[]
for i,line in enumerate(lines):
    if risk_words.search(line):
        # is 'derive' or 'Derived' within 2 lines? (potential mislabel)
        window=''.join(lines[max(0,i-2):i+3])
        if re.search(r'[Dd]erive',window):
            hits.append((i+1,line.strip()[:90]))
if hits:
    print(f"   {len(hits)} spots with assumption-language near 'derive' (review each):")
    for ln,ctx in hits[:12]: print(f"   line {ln}: {ctx}")
else:
    print("   none — no assumption-language adjacent to derivation claims. GOOD.")

# count cross-references per paper (connectivity to Paper 1 substrate)
print(f"\n3. CONNECTIVITY TO FOUNDATION (B̄=3ᾱ / Paper 1 references per paper):")
found_eq=re.compile(r'3\\?bar|bar\{B\}|3\\bar\{\\alpha\}|B̄|triadic|\[\[4,2,2\]\]|FCC|confirmation')
for j in range(len(bounds)):
    start=bounds[j][0]
    end=bounds[j+1][0] if j+1<len(bounds) else len(lines)
    seg=''.join(lines[start-1:end-1])
    n_found=len(found_eq.findall(seg))
    print(f"   {bounds[j][1]:12} (lines {start}-{end}): {n_found} foundation-refs")
