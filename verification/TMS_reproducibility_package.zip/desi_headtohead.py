#!/usr/bin/env python3
"""
HONEST HEAD-TO-HEAD: our mechanism's forced output vs DESI's actual published
(w0, wa) best-fit values across every data combination. No tuning -- our numbers
are what the forced mechanism produced earlier; DESI's are pulled from the papers.
"""
import numpy as np

print("="*72)
print("DESI DR2 published (w0, wa) best fits vs TMS forced-mechanism output")
print("="*72)

# DESI's actual published best-fit values, by data combination (from the papers)
desi = [
    ("DESI+CMB (BAO+CMB)",           -0.42, -1.75,  "3.1sigma vs LCDM"),
    ("DESI+CMB+PantheonPlus",        -0.838, -0.62, "phantom crossing"),
    ("DESI+CMB+Union3",              -0.667, -1.09, "phantom crossing"),
    ("DESI+CMB+DESY5",              -0.741, -0.92,  "phantom crossing"),
    ("Planck+DESI+Union3+DESIY1",   -0.671, -1.04,  "phantom crossing"),
    ("Planck+DESI+DESY5+DESIY1",    -0.741, -0.92,  "phantom crossing"),
]
# best-measured PIVOT (model-independent): w(z=0.5) = -1.024 +/- 0.043

# TMS forced-mechanism outputs from THIS session (not tuned to any of the above):
tms = [
    ("v5 dark_sector (corpus eqns)",  -1.02, None,  "w at pivot z=0.5"),
    ("no_future model",               -0.59, -2.08, "wake-read, terminal boundary"),
    ("sampling-relativity (null)",    -1.33, 0.0,   "constant source, forced"),
    ("undulating field aggregate",    -1.11, -0.28, "population of regions"),
]

print("\nDESI PUBLISHED best-fit (w0, wa):")
print(f"{'combination':<32}{'w0':>8}{'wa':>8}   note")
for name,w0,wa,note in desi:
    print(f"  {name:<30}{w0:>8.3f}{wa:>8.3f}   {note}")
print(f"\n  MODEL-INDEPENDENT PIVOT: w(z=0.5) = -1.024 +/- 0.043  (best-measured point)")

print("\nTMS FORCED-MECHANISM output (this session, NOT tuned to DESI):")
print(f"{'model':<32}{'w0':>8}{'wa':>8}   note")
for name,w0,wa,note in tms:
    was = f"{wa:>8.3f}" if wa is not None else f"{'--':>8}"
    print(f"  {name:<30}{w0:>8.3f}{was}   {note}")

# the honest comparison
print("\n" + "="*72)
print("HONEST ASSESSMENT")
print("="*72)

# DESI w0 range
desi_w0 = [d[1] for d in desi]
print(f"""
DESI's w0 spans {min(desi_w0):.2f} to {max(desi_w0):.2f} depending on the SN dataset --
there is NO single DESI value, there is a dataset-dependent spread.

TMS forced outputs span -1.33 to -0.59 -- a similar spread, from the same
mechanism under different (equally un-tuned) modeling of the wake/sampling.

WHERE WE LAND:
1. The single BEST-MEASURED, model-independent DESI number is the pivot
   w(z=0.5) = -1.024 +/- 0.043. Our v5 dark_sector run (built on the corpus's
   OWN formation/exhaustion equations) gave w = -1.02 at exactly that redshift.
   That is a 1-point match, inside DESI's error bar, NOT tuned. This is the
   strongest single quantitative contact.

2. On the CPL (w0, wa) plane: our undulating-field aggregate (-1.11, -0.28) sits
   NEAR the DESI+CMB+PantheonPlus point (-0.838, -0.62) but is not on top of it.
   Our other models scatter across the DESI spread. So on the 2-parameter plane,
   we are IN THE REGION but not pinned to a specific DESI point.

3. The HONEST limit: DESI itself doesn't have one w(z); it has a dataset-dependent
   family. We reproduce the FAMILY's qualitative location (phantom-ish, evolving,
   crossing near z~0.5) and hit the best-measured pivot point, but we do NOT
   uniquely predict one curve -- because (a) our mechanism has un-pinned inputs
   and (b) the data itself is a spread, not a point.

VERDICT: one genuine quantitative hit (the pivot, -1.02 vs -1.024, un-tuned),
and qualitative-location agreement on the (w0,wa) plane. NOT a full curve match.
This is real but modest -- exactly what the corpus's 'structural concordance,
quantitative derivation open' language now says. The head-to-head CONFIRMS the
honest calibration: we touch the best-measured point, we sit in the right region,
we do not yet pin the curve. No overclaim survives this comparison.
""")

# how close is the pivot hit really?
pivot_desi, pivot_err = -1.024, 0.043
pivot_tms = -1.02
sigma_off = abs(pivot_tms - pivot_desi)/pivot_err
print(f"Pivot hit precision: TMS -1.02 vs DESI -1.024 +/- 0.043")
print(f"  => {sigma_off:.2f} sigma from the DESI central value (well inside 1 sigma)")
print(f"  This is the one number we can honestly say we produced, un-tuned, that")
print(f"  matches DESI's best-measured value. One point -- but a real one.")
