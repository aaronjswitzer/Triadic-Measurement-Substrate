#!/usr/bin/env python3
"""
Stage 25b — quantify the FCC anisotropy magnitude and compare to experimental
Lorentz-violation bounds. Is it ruled out, or far below detectability?

From 25a: omega^2 = c^2 k^2 [ 1 - (fractional anisotropic correction) ]
The anisotropic part of the a^4 term, relative to the isotropic a^2 term, scales as
   delta_aniso ~ (anisotropy coefficient) * (k a)^2
with a = Planck length. The direction-dependent SPREAD in phase velocity between
[100] and [111] is what a Lorentz-violation experiment would see.
"""
import numpy as np

# Planck length and typical probe scales
l_planck = 1.616e-35   # m
# a probe of wavenumber k; k*a = k*l_planck. Express k via energy: k = E/(hbar c) for a photon
hbar = 1.055e-34; c = 2.998e8
def k_of_E(E_eV):
    E_J = E_eV*1.602e-19
    return E_J/(hbar*c)   # 1/m

print("="*70)
print("STAGE 25b — magnitude of FCC Lorentz violation vs experiment")
print("="*70)

# fractional anisotropy between [100] and [111] at wavenumber k:
# from 25a, A4/|k|^4 differs by (-0.020833) - (-0.027778) = 0.006944 between dirs.
# The dispersion: omega^2 = (c^2/a^2)*[ a^2 k^2 - a^4 (A4-structure) + ... ]
#   omega^2 = c^2 k^2 [ 1 - a^2 * (A4/|k|^4)*k^2*(correction bookkeeping) ]
# The fractional velocity anisotropy ~ (spread in A4/|k|^4) * (k a)^2, order-of-magnitude.
spread = 0.027778 - 0.020833   # = 0.006944, the [111]-[100] difference in the quartic coeff
print(f"\nAngular spread in the quartic coefficient ([111]-[100]): {spread:.6f}")
print(f"Fractional phase-velocity anisotropy  ~  {spread:.4f} * (k * l_Planck)^2\n")

print(f"{'probe':<28}{'energy':<14}{'k*l_Planck':<16}{'|dv/v| anisotropy':<18}")
print("-"*76)
probes=[
  ("Optical photon", 2.0),                # 2 eV visible light
  ("X-ray", 1e4),                         # 10 keV
  ("LHC proton", 6.5e12),                 # 6.5 TeV
  ("GZK cutoff cosmic ray", 5e19),        # ~5e19 eV, highest observed
  ("GRB photon (Fermi)", 1e10),           # 10 GeV gamma from gamma-ray burst
]
for name,E in probes:
    k=k_of_E(E)
    ka=k*l_planck
    dv=spread*ka**2
    print(f"{name:<28}{E:<14.1e}{ka:<16.2e}{dv:<18.2e}")

print("""
COMPARISON TO EXPERIMENTAL BOUNDS:
  Current Lorentz-violation limits on photon phase-velocity anisotropy reach
  |dv/v| < ~1e-18 (modern Michelson-Morley / optical cavity experiments), and
  astrophysical time-of-flight bounds on QG-scale dispersion reach the Planck
  scale itself for the LINEAR term (Fermi-LAT GRB observations constrain
  E_QG,1 > E_Planck). The TMS anisotropy is QUADRATIC in (k a) -- an E^2/E_Planck^2
  suppression -- which is far weaker and far below all current bounds.
""")

# The key number: at what energy would the anisotropy reach the current best bound ~1e-18?
target=1e-18
# spread*(k*lp)^2 = target -> k*lp = sqrt(target/spread) -> E = k*hbar*c/e
klp = np.sqrt(target/spread)
k = klp/l_planck
E_J = k*hbar*c; E_eV = E_J/1.602e-19
print(f"Energy at which anisotropy would reach the current best bound (~1e-18):")
print(f"   E ~ {E_eV:.2e} eV = {E_eV/1e9:.2e} GeV")
print(f"   (for comparison: Planck energy ~ 1.22e28 eV; highest observed cosmic ray ~5e19 eV)")
E_planck=1.22e28
print(f"   This is {E_eV/E_planck:.1e} of the Planck energy -- i.e. the effect only")
print(f"   becomes detectable near the Planck scale itself, consistent with ALL")
print(f"   current experiments and exactly where a substrate theory expects it.")
