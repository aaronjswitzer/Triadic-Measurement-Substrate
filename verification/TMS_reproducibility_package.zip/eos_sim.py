#!/usr/bin/env python3
"""
CORRECTED, and NOT fitted to produce a crossing. The v1 model had w stuck at -1.5
forever (no crossing) because the surface-area growth a^2 in the advance term
overpowered the depth suppression, so density grew monotonically. That was a
genuine modeling error, OR the framework genuinely doesn't cross -- we find out by
fixing the identifiable error and reporting whatever results.

THE IDENTIFIABLE ERROR: dark energy DENSITY is per unit VOLUME. The now-surface
residual is injected on a 2D surface (area ~ a^2 comoving -> but physical area and
the volume it dilutes into both scale with expansion). The residual DENSITY (per
physical volume) is (surface residual)/(volume) -- the a^2 injection is diluted by
the a^3 volume. Net, the injection PER VOLUME scales as a^2/a^3 = 1/a, NOT a^2.

This is the area/volume ratio the corpus itself emphasizes (the factor-of-2, area
over volume). I put area in the numerator but forgot the volume in the denominator.

Corrected advance-per-volume:  advance_V(a) = (1/a) * (1/sqrt2)^{k(a)}
Everything else as before, still NOT tuned to DESI.
"""
import numpy as np

print("="*70)
print("Corrected EoS simulation (density per volume; not fitted)")
print("="*70)

a = np.linspace(0.15, 3.0, 6000)
s = np.log(a)
loga2 = np.log2(a)
k0 = 4.0
k = k0 + loga2
depth_weight = (1/np.sqrt(2))**k

# CORRECTED: injection per unit volume = surface(a^2)/volume(a^3) * depth = (1/a)*depth
advance_V = (1.0/a) * depth_weight

# residual density ODE, dilution D=2 (area/volume factor, from the corpus)
D = 2.0
rho = np.zeros_like(a); rho[0] = advance_V[0]/D
ds = np.gradient(s)
for i in range(1,len(a)):
    rho[i] = rho[i-1] + (advance_V[i] - D*rho[i-1])*ds[i]
rho = np.maximum(rho,1e-12)

dlnrho = np.gradient(np.log(rho), s)
w = -1 - (1/3)*dlnrho

def nn(arr,v): return int(np.argmin(np.abs(arr-v)))
i0 = nn(a,1.0); w0 = w[i0]
mask=(a>0.7)&(a<1.3)
coef,_,_,_ = np.linalg.lstsq(np.vstack([np.ones(mask.sum()),(1-a[mask])]).T, w[mask], rcond=None)
w0c, wac = coef
cross = np.where(np.diff(np.sign(w+1)))[0]
cross_z = [1/a[c]-1 for c in cross]
pk = int(np.argmax(rho)); pkz = 1/a[pk]-1

print(f"\nRead-out (corrected, not DESI-fitted):")
print(f"  w_0 today       = {w0:+.3f}")
print(f"  w_0 (CPL)       = {w0c:+.3f}")
print(f"  w_a (CPL)       = {wac:+.3f}")
print(f"  w=-1 crossing z = {[f'{z:+.2f}' for z in cross_z] if len(cross_z) else 'NONE'}")
print(f"  density peak z  = {pkz:+.2f}")

early=w[nn(a,0.3)]; late=w[nn(a,2.5)]
print(f"\nShape:")
print(f"  early z~2.3: w={early:+.3f} {'phantom' if early<-1 else 'quint'}")
print(f"  today z=0:   w={w0:+.3f}")
print(f"  future:      w={late:+.3f} {'quint' if late>-1 else 'phantom'}")
crosses = early<-1 and late>-1
print(f"  crosses -1 below->above: {'YES' if crosses else 'NO'}")

print(f"\nw(a) table:")
print(f"{'z':>7}{'a':>7}{'w':>9}{'rho/rho0':>10}")
for zt in [3,2,1,0.5,0,-0.3,-0.6]:
    at=1/(1+zt)
    if a[0]<=at<=a[-1]:
        i=nn(a,at); print(f"{zt:>7.1f}{at:>7.3f}{w[i]:>9.3f}{rho[i]/rho[i0]:>10.3f}")

print("\n"+"="*70)
print("HONEST READING -- whatever it actually shows")
print("="*70)
if crosses and len(cross_z)>0 and cross_z[0]>0:
    print(f"""
The corrected model (density per volume) DOES cross w=-1, from phantom (early) to
quintessence (late), crossing at z={cross_z[0]:+.2f} with density peaking at
z={pkz:+.2f}. The single correction -- accounting for the volume dilution of the
surface injection -- changed a monotonic (non-crossing) density into one that
peaks and turns over, producing the crossing. This was NOT tuned to DESI; the
correction is the area/volume ratio the corpus already uses.
  w_0 ~ {w0c:+.2f}, w_a ~ {wac:+.2f}, crossing z ~ {cross_z[0]:.2f}.""")
else:
    print(f"""
The corrected model gives: crossing = {crosses}, crossing redshifts = {cross_z}.
w_0 ~ {w0c:+.2f}, w_a ~ {wac:+.2f}, peak z = {pkz:+.2f}.
Report exactly this, whatever it is -- no dressing.""")
print("""
DISCIPLINE NOTE: v1 did NOT cross (w stuck at -1.5) and I must not pretend it did.
This v2 makes ONE physically-motivated correction (volume dilution of the surface
residual, = the corpus's own area/volume factor) identified WITHOUT reference to
the desired answer. If it now crosses, that is a real (if model-level) result; if
it still does not, the honest statement is that the crossing is asserted in the
corpus but not yet reproduced by a forward simulation, and that must be recorded.
""")
