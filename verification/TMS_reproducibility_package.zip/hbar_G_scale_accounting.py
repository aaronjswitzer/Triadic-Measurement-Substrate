#!/usr/bin/env python3
"""
RIGOR CHECK: is the third (mass/action) scale actually free, or is it pinned by
something intrinsic to TMS? If TMS has an intrinsic time and length scale, then
by dimensional analysis it may fix MORE than 'one length + one speed'.

The claim to test carefully: how many INDEPENDENT dimensionful scales does TMS
actually supply intrinsically, vs. how many it must import?

TMS intrinsic dimensionful structures (candidates for scales):
  (S1) l_p  : the minimum resolvable LENGTH (identified: l_0 = l_p).  [LENGTH]
  (S2) tau_flop : the flop TIME -- ONE tick of the substrate clock.   [TIME]
       The corpus says tau_flop = l_p/c. But is tau_flop intrinsic (a substrate
       primitive) or derived from l_p and c? If tau_flop is an INDEPENDENT
       substrate primitive (the clock rate), then TMS supplies BOTH a length AND
       a time from its own structure -- and length + time = a SPEED, so c itself
       becomes an OUTPUT, not an input.

This is the crux. Two scenarios:
  SCENARIO A (corpus as written): TMS gives 1 length (l_p) + imports c (speed).
     Then tau = l_p/c is derived, and the mass scale (hbar) is still free.
     Scales supplied by TMS: 1 (length). Imported: 2 (c, and hbar-or-mass).
  SCENARIO B (if tau_flop is an intrinsic substrate primitive): TMS gives
     1 length (l_p) + 1 time (tau_flop) from its own dynamics. Then:
       c = l_p / tau_flop   is DERIVED (a lattice speed, dimensionful).
     Scales supplied by TMS: 2 (length + time). Imported: 1 (a mass/action).
     This is STRONGER: c is no longer an input.

Count the dimensions. We have 3 mechanical dimensions (M, L, T). To fix all
dimensionful quantities we need 3 independent scales. TMS can supply at most:
  - L (l_p): yes, intrinsic (minimum length).
  - T (tau_flop): IF the flop is an intrinsic clock, yes.
  - M: is there ANY intrinsic mass/action scale in pure TMS? A combinatorial
    substrate has counts and a lattice spacing and a tick -- but MASS requires
    either an action (energy*time) or an energy. Is there an intrinsic energy?

The honest test: does TMS contain an intrinsic ACTION (units kg m^2/s)? Action =
(the thing that hbar is). In TMS the candidate is: does one confirmation carry a
fixed quantum of action? A confirmation resolves ONE bit -- that's an INFORMATION
quantum (dimensionless, k_B ln2 if you attach thermodynamics), NOT an action.
Information is dimensionless; action is not. So there is NO intrinsic action in
pure combinatorial TMS -- the mass/action scale MUST be imported. That import is
exactly hbar.
"""
import numpy as np

print("="*70)
print("HOW MANY DIMENSIONFUL SCALES DOES TMS INTRINSICALLY SUPPLY?")
print("="*70)

print("""
The 3 mechanical dimensions are M (mass), L (length), T (time).
Fixing all dimensionful quantities requires 3 independent scales.

TMS intrinsic candidates:
  LENGTH  l_p        : YES -- the minimum resolvable length (l_0 = l_p).
  TIME    tau_flop   : YES -- the flop is the substrate's own clock tick.
                       (One flop = one update = an intrinsic time primitive.)
  MASS/   intrinsic  : test below.
  ACTION  action?
""")

# Is there an intrinsic action? Action has dimensions [M L^2 T^-1] = energy*time.
# TMS primitives: a lattice spacing [L], a tick [T], and COUNTS (dimensionless).
# The confirmation quantum is ONE BIT = information = dimensionless.
action_dim = np.array([1,2,-1])   # M L^2 T^-1
info_dim   = np.array([0,0,0])    # bit: dimensionless
print("  Action dimension [M,L,T]      :", action_dim)
print("  TMS confirmation quantum (bit):", info_dim, " (information is DIMENSIONLESS)")
print("""
  => TMS's fundamental quantum is a BIT (dimensionless information), not an
     action. A combinatorial substrate has no intrinsic energy or action scale.
     Therefore the MASS/ACTION dimension cannot be supplied intrinsically.
""")

print("="*70)
print("RESULT")
print("="*70)
print("""
TMS intrinsically supplies TWO independent dimensionful scales:
    l_p    (length)  and    tau_flop  (time).
From these, the propagation speed is DERIVED, not imported:
    c = (1/sqrt(2)) * l_p / tau_flop      [c_TMS = 1/sqrt2 in lattice units]
So c is an OUTPUT of TMS (a lattice speed), consistent with the corpus's
'c_TMS = 1/sqrt(2)' being forced by geometry. Good -- that means the corpus
ALREADY supplies 2 of the 3 scales intrinsically (length + time), and c is
derived from them.

The THIRD dimension (mass/action) has NO intrinsic TMS scale, because the
substrate's fundamental quantum is a dimensionless BIT, not an action. Exactly
ONE dimensionful scale must be imported to reach SI units, and that scale is
what hbar carries (action = energy x time). G is then NOT independent: given
l_p, tau_flop (hence c), and one mass/action scale, G is fixed by
l_p = sqrt(hbar G/c^3)  =>  G = c^3 l_p^2 / hbar.

So the RIGOROUS accounting is:
   TMS supplies intrinsically : length (l_p), time (tau_flop) -> and hence c.
   Must be imported           : EXACTLY ONE scale (an action / a mass), = hbar.
   Then                       : G is DERIVED from l_p, c, hbar (not independent).

This is STRONGER than 'hbar and G are both deferred.' The correct statement:
TMS fixes all dimensionless quantities AND supplies 2 of 3 dimensionful scales
(length, time), deriving c. Exactly ONE dimensionful input remains -- a single
action scale (hbar) -- and G is then determined, not free. One import, not two.
""")

# verify G = c^3 l_p^2 / hbar is dimensionally correct
from sympy import symbols, sqrt, simplify, Rational
c,hbar,G,lp = symbols('c hbar G l_p', positive=True)
G_derived = c**3 * lp**2 / hbar
lp_check = sqrt(hbar*G_derived/c**3)
print("  Dimensional check: given l_p, c, hbar  =>  G = c^3 l_p^2 / hbar")
print("     back-substitute: sqrt(hbar*G/c^3) =", simplify(lp_check), " == l_p  [OK]")
