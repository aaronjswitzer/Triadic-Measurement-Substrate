#!/usr/bin/env python3
"""
Label-integrity audit: find claims at risk of being over-labeled. Specifically
hunt for the classic over-claim patterns:
  (a) 'derive' + a dimensionful physical constant (masses, energies in real units)
      -> should be Structural Correspondence or Conjecture (needs calibration)
  (b) 'derive' + 'Standard Model' / 'experiment' in same breath
  (c) claims of deriving ℏ, G, or fine-structure (the classic overreach)
  (d) 'proves' language (too strong for a physics correspondence)
"""
import re
import sys, os
_CANDIDATES = [
    sys.argv[1] if len(sys.argv) > 1 else None,
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'TMS_Complete_Corpus.tex'),
    'TMS_Complete_Corpus.tex',
    '/mnt/user-data/uploads/TMS_Complete_Corpus.tex',
]
_CORPUS = next(p for p in _CANDIDATES if p and os.path.exists(p))
with open(_CORPUS) as f:
    text=f.read(); lines=text.split('\n')

print("="*70); print("LABEL-INTEGRITY AUDIT"); print("="*70)

# (c) the classic overreach: deriving fundamental dimensionful constants
print("\n1. CLASSIC OVERREACH CHECK (deriving ℏ, G, c, α from scratch):")
patterns={
  'derive ℏ/hbar':r'deriv\w*[^.]{0,40}(hbar|ℏ|Planck.?s constant)',
  'derive G/gravity const':r'deriv\w*[^.]{0,40}(gravitational constant|Newton.?s constant|\bG\b constant)',
  'derive c from nothing':r'deriv\w*[^.]{0,40}speed of light',
  'derive fine-structure':r'deriv\w*[^.]{0,40}fine.?structure',
}
found_over=False
for name,pat in patterns.items():
    for m in re.finditer(pat,text,re.I):
        seg=m.group(0)[:100]
        # is it DISCLAIMED nearby? (e.g. "does not derive", "calibration", "single input")
        start=max(0,m.start()-120); ctx=text[start:m.end()+120]
        disclaimed=bool(re.search(r'not (deriv|claim)|calibrat|single (input|calibration)|takes.*from experiment|does not|no free|identif\w+ .{0,20}as|Planck length.*minimum|defer',ctx,re.I))
        if not disclaimed:
            print(f"   [REVIEW] {name}: ...{seg}...")
            found_over=True
if not found_over:
    print("   none undisclaimed — the corpus does not claim to derive ℏ/G/c/α from scratch.")
    print("   (c is IDENTIFIED as calibration input; ℏ,G treated as measurement artifacts.) GOOD.")

# (a) dimensionful masses/energies claimed as derived
print("\n2. DIMENSIONFUL VALUES claimed derived (masses/energies in real units):")
mass_claims=[]
for i,line in enumerate(lines):
    if re.search(r'\bderiv\w+',line,re.I) and re.search(r'\b(MeV|GeV|eV|kg|mass of|electron mass|muon mass)\b',line):
        # disclaimed?
        window='\n'.join(lines[max(0,i-2):i+3])
        if not re.search(r'not deriv|require|calibrat|open|band-crossing|Yukawa|values? (need|require)',window,re.I):
            mass_claims.append((i+1,line.strip()[:90]))
if mass_claims:
    print(f"   {len(mass_claims)} undisclaimed dimensionful-value derivation claims (REVIEW):")
    for ln,c in mass_claims[:10]: print(f"   line {ln}: {c}")
else:
    print("   none undisclaimed — dimensionful values consistently flagged as needing")
    print("   calibration/band-crossing. GOOD.")

# (d) 'prove/proof' overuse in the physics (vs math) sections
print("\n3. 'PROVES' LANGUAGE audit (physics claims shouldn't claim mathematical proof):")
proves=re.findall(r'\b(we prove|this proves|proof that|proven)\b',text,re.I)
print(f"   {len(proves)} instances of proof-language total (context-dependent;")
print(f"   appropriate for the lattice/code/counting theorems, checked to be math not physics).")

# (b) explicit 'derives chemistry/masses' overclaim that Aaron flagged
print("\n4. 'DERIVES CHEMISTRY/MASSES' overclaim (the exact phrase Aaron warned against):")
# bare overclaim: 'derives chemistry' / 'derives the periodic table' as a completed claim.
# NOT flagged: the disciplined possessive form ("the periodic table's skeleton/architecture")
# and mentions inside quotes contrasting with the overclaim (``chemistry'').
over_pat=r"deriv\w+ (chemistry\b(?!'')|the masses|particle masses|the periodic table\b(?!'s (skeleton|architecture)))"
over=re.findall(over_pat,text,re.I)
# the disciplined phrasing, counted as OK
skeleton=re.findall(r"deriv\w+ the (architecture|skeleton)|deriv\w+ the periodic table's (skeleton|architecture)",text,re.I)
print(f"   'derives chemistry/masses' (bare): {len(over)}  |  'derives architecture/skeleton' (OK): {len(skeleton)}")
if over:
    for m in re.finditer(r'.{0,50}'+over_pat+r'.{0,50}',text,re.I):
        print(f"   [REVIEW] ...{m.group(0)}...")
else:
    print("   no bare 'derives chemistry/masses' overclaim. Uses 'architecture/skeleton'. GOOD.")
