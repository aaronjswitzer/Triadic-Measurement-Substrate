#!/usr/bin/env python3
"""
TMS Paper 5, Appendix E, Stage 10 (HONEST PROBE -- not a confirmation)
Cascade-Collapse Statistics: are the corpus's Bucket-B conjectures
(power-law cascades, 1/f emergence) simulable, or are they artifacts of
unspecified modeling choices?

The corpus (Paper 2 S3.x) flags these as CONJECTURES "pending Paper 5's
simulation work": power-law statistics for cascade collapse, scale-free
correlation lengths, 1/f signatures in emergence rates.

To simulate a cascade we need a dynamical process: a configuration
evolving under T (the majority flop, Stage 9) with U_sh disruption
injected. The corpus does NOT specify the disruption rate or its spatial
structure. This stage tests whether the qualitative statistics
(power-law vs exponential) DEPEND on those unspecified choices. If they
do, the conjectures are not yet simulable -- any "power law" would be an
artifact of our choice, not a TMS prediction.

We run an avalanche-style model: perturb a stabilized patch at one site,
let T relax it, and measure the CASCADE SIZE = number of sites that flip
before re-stabilizing. We do this under two equally-defensible but
DIFFERENT disruption models and compare the cascade-size distributions.
"""
import itertools
import numpy as np
from collections import Counter


def fcc_patch(L):
    return [(i, j, k) for i in range(L) for j in range(L) for k in range(L)
            if (i + j + k) % 2 == 0]


def fcc_neighbors_periodic(site, L):
    i, j, k = site
    out = []
    for di, dj, dk in itertools.product((-1, 0, 1), repeat=3):
        if di*di + dj*dj + dk*dk == 2:
            n = ((i+di) % L, (j+dj) % L, (k+dk) % L)
            if (n[0]+n[1]+n[2]) % 2 == 0:
                out.append(n)
    return out


def relax(state, sites, nbr_idx, max_iter=200):
    """Synchronous majority relaxation until fixed point or max_iter.
    Returns (final_state, n_sites_that_ever_flipped vs initial)."""
    s = state.copy()
    initial = state.copy()
    for _ in range(max_iter):
        new = s.copy()
        for i in range(len(sites)):
            vals = s[nbr_idx[i]]
            ones = vals.sum(); zeros = len(vals) - ones
            if ones > zeros:
                new[i] = 1
            elif zeros > ones:
                new[i] = 0
            # tie: hold
        if np.array_equal(new, s):
            break
        s = new
    flipped = int((s != initial).sum())
    return s, flipped


def cascade_sizes(L, n_trials, disruption, seed):
    """disruption: 'single' flips 1 random site; 'cluster' flips a random
    site AND its neighbours. Both are defensible U_sh models."""
    rng = np.random.default_rng(seed)
    sites = fcc_patch(L)
    n = len(sites)
    idx = {s: i for i, s in enumerate(sites)}
    nbr_idx = [np.array([idx[x] for x in fcc_neighbors_periodic(s, L)])
               for s in sites]

    # start from a stabilized state (relax a random config once)
    base = rng.integers(0, 2, n)
    base, _ = relax(base, sites, nbr_idx)

    sizes = []
    for _ in range(n_trials):
        s = base.copy()
        site = rng.integers(0, n)
        if disruption == "single":
            s[site] ^= 1
        else:  # cluster
            s[site] ^= 1
            for j in nbr_idx[site]:
                s[j] ^= 1
        _, flipped = relax(s, sites, nbr_idx)
        sizes.append(flipped)
    return np.array(sizes)


def describe(sizes, label):
    nz = sizes[sizes > 0]
    print(f"  {label:>10}: n={len(sizes)} mean={sizes.mean():.2f} "
          f"max={sizes.max()} nonzero={len(nz)} "
          f"frac_large={np.mean(sizes > sizes.mean()*3):.3f}")
    return Counter(sizes.tolist())


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("STAGE 10 -- cascade-size distributions under TWO disruption models")
    print("(testing whether Bucket-B statistics depend on unspecified choices)\n")

    L = 8
    n_trials = 4000
    single = cascade_sizes(L, n_trials, "single", seed=1)
    cluster = cascade_sizes(L, n_trials, "cluster", seed=1)

    print(f"patch L={L}, {len(fcc_patch(L))} sites, {n_trials} avalanches each\n")
    c1 = describe(single, "single")
    c2 = describe(cluster, "cluster")

    # crude power-law-vs-exponential discriminator: look at the tail.
    # Power law => heavy tail (many large cascades); exponential => light.
    def tail_ratio(sizes):
        nz = sizes[sizes > 0]
        if len(nz) < 10:
            return float('nan')
        # ratio of 90th to 50th percentile; large => heavier tail
        return np.percentile(nz, 90) / max(np.percentile(nz, 50), 1)

    print(f"\n  tail ratio (P90/P50) single : {tail_ratio(single):.2f}")
    print(f"  tail ratio (P90/P50) cluster: {tail_ratio(cluster):.2f}")

    print("\n" + "="*60)
    print("VERDICT ON BUCKET B")
    print("="*60)
    same_shape = abs(tail_ratio(single) - tail_ratio(cluster)) < 0.5
    print(f"  the two defensible disruption models give "
          f"{'SIMILAR' if same_shape else 'DIFFERENT'} tail shapes")
    print("  => If DIFFERENT, the cascade statistics are not a TMS")
    print("     prediction but a consequence of the (unspecified) U_sh")
    print("     model. The corpus is correct to label them CONJECTURES;")
    print("     they are NOT yet simulable as stated. (honest non-result)")
