#!/usr/bin/env python3
"""
TMS Paper 5, Appendix B.5 — the k = 3·L_box null-space regularity.

B.5 asserts (but never shows) the F2 constraint RANKS of the Z-stabilizer
(tetrahedral parity) map on FCC patches:
    L_box:  1   2   3   4
    (N,T): (4,1)(14,8)(32,27)(63,64)
    rank:   1   8   23  51
    k=N-r:  3   6   9   12   = 3·L_box  ✓ (for L_box in {1,2,3,4})
and leaves OPEN whether k = 3·L_box persists for L_box ≥ 5.

Stage 5 verified the null-space DIMENSIONS (3,6,9,12) but reported k=N-rank,
not the ranks themselves. Here we verify B.5's exact ranks AND push past
L_box=4 to settle the open question by direct computation.

NOTE on lattice convention: B.5 uses the level-0 FCC patch (sites i+j+k even)
— NOT the per-sublattice level-1 patch of Stage 5. We compute the parity map
over FCC tetrahedra on the i+j+k even patch, matching the (N,T) counts B.5
states. (Cross-check: B.5's (N,T) = (4,1),(14,8),(32,27),(63,64) — we confirm
these reproduce, which also re-validates the lattice convention.)
"""
import itertools
import numpy as np
from tms_dynamics import fcc_neighbors


def fcc_even_patch(L):
    """Level-0 FCC: integer sites in [0,L)^3 with i+j+k even."""
    return [(i, j, k) for i in range(L) for j in range(L) for k in range(L)
            if (i + j + k) % 2 == 0]


def sqdist(a, b):
    return sum((a[i]-b[i])**2 for i in range(3))


def find_tetrahedra(sites):
    """4-cliques at mutual FCC NN sq-dist 2."""
    ss = set(sites)
    idx = {s: i for i, s in enumerate(sites)}
    adj = {s: set(fcc_neighbors(s, ss)) for s in sites}
    sl = sorted(sites)
    tets = []
    for a in sl:
        for b in adj[a]:
            if b <= a:
                continue
            for c in adj[a] & adj[b]:
                if c <= b:
                    continue
                for d in adj[a] & adj[b] & adj[c]:
                    if d <= c:
                        continue
                    tets.append((a, b, c, d))
    return tets, idx


def gf2_rank(M):
    A = (M.copy() % 2).astype(np.uint8)
    rows, cols = A.shape
    r = 0
    for c in range(cols):
        piv = -1
        for i in range(r, rows):
            if A[i, c]:
                piv = i; break
        if piv < 0:
            continue
        A[[r, piv]] = A[[piv, r]]
        for i in range(rows):
            if i != r and A[i, c]:
                A[i] ^= A[r]
        r += 1
        if r == rows:
            break
    return r


def parity_map_rank(sites, tets, idx):
    """Rank over F2 of the tet×site parity matrix."""
    if not tets:
        return 0
    M = np.zeros((len(tets), len(sites)), dtype=np.uint8)
    for t, tet in enumerate(tets):
        for s in tet:
            M[t, idx[s]] = 1
    return gf2_rank(M)


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("STAGE 12 — Appendix B.5 rank regularity\n")
    print(f"{'Lbox':>4} {'N':>4} {'T':>4} {'rank':>5} {'k=N-r':>6} "
          f"{'3·Lbox':>7} {'match':>6}")

    claimed = {  # B.5 stated values
        1: dict(N=4, T=1, rank=1),
        2: dict(N=14, T=8, rank=8),
        3: dict(N=32, T=27, rank=23),
        4: dict(N=63, T=64, rank=51),
    }

    results = {}
    all_match = True
    persists = True
    for L in range(1, 8):
        sites = fcc_even_patch(L + 1)  # [0,L]^3 inclusive-ish to get B.5's N
        # B.5's N at Lbox: 4,14,32,63 correspond to box sizes giving those counts
        tets, idx = find_tetrahedra(sites)
        N = len(sites); T = len(tets)
        rank = parity_map_rank(sites, tets, idx)
        k = N - rank
        target = 3 * L
        match = (k == target)
        all_match = all_match and (L > 4 or match)
        if L >= 5 and not match:
            persists = False
        results[L] = dict(N=N, T=T, rank=rank, k=k)
        flag = "Y" if match else "n"
        print(f"{L:>4} {N:>4} {T:>4} {rank:>5} {k:>6} {target:>7} {flag:>6}")

    print("\n" + "="*60)
    print("CHECK vs B.5 stated ranks (Lbox 1-4)")
    print("="*60)
    rank_match = True
    for L, cl in claimed.items():
        got = results[L]
        ok = (got["N"] == cl["N"] and got["T"] == cl["T"]
              and got["rank"] == cl["rank"])
        rank_match = rank_match and ok
        print(f"  Lbox={L}: (N,T,rank) claimed {(cl['N'],cl['T'],cl['rank'])} "
              f"got {(got['N'],got['T'],got['rank'])}  {'OK' if ok else 'MISMATCH'}")

    print("\n" + "="*60)
    print("OPEN QUESTION: does k = 3·Lbox persist for Lbox >= 5?")
    print("="*60)
    for L in range(5, 8):
        got = results[L]
        print(f"  Lbox={L}: k={got['k']}, 3·Lbox={3*L}, "
              f"{'holds' if got['k']==3*L else 'BREAKS'}")
    print(f"\n  VERDICT: k=3·Lbox {'PERSISTS' if persists else 'BREAKS'} "
          f"beyond Lbox=4 (settling B.5's open question)")
    print(f"  B.5 stated ranks (1-4): {'CONFIRMED' if rank_match else 'MISMATCH'}")
