#!/usr/bin/env python3
"""
TMS Paper 5 §6.1.3 / App. B.4 + Paper 3 §2.5 — program-zoo, CORRECTED.

The first Stage-13 harness rejected non-parity configs and got zero. That was
wrong: Paper 3 §2.5 (Dissolution & Convergence Theorem) says non-parity configs
are not rejected but REPAIRED to the nearest parity-satisfying config in one
flop (case iii), then evolve by (i)/(ii). And the program-identity test is
exactly case (i): stabilizer-parity AND T-closed under the SINGLE-LEVEL T
(which we have, spec §1) -> persists = is a program.

So the zoo = {configs that, after one repair step, are stabilizer-parity AND
T-closed (period <= n_max)}. We enumerate, repair, test closure, and count —
AND examine whether the survivors carry the claimed structure (central
[[4,2,2]] logical state x O_h orientation).

Honesty note: §2.5 settles the program-IDENTITY criterion at single level (no
cross-level map needed for THIS). The separate claim that the meta-level
triadic rule reappears under G (form-invariance) is NOT what the 96-count
needs; the 96-count needs only (i)-persistence, which is now testable.
"""
import itertools
import numpy as np
from tms_dynamics import flop, equal_up_to_translation, fcc_neighbors


def coord_sum_mod4(s): return (s[0]+s[1]+s[2]) % 4
def sqdist(a, b): return sum((a[i]-b[i])**2 for i in range(3))
def all_odd(s): return all(c % 2 == 1 for c in s)


# ---- tile + boundary on level-1 sublattices (small, exhaustively closeable) ----
def build_tile():
    cand = [(i, j, k) for i in (1, 3) for j in (1, 3) for k in (1, 3)]
    A = [s for s in cand if coord_sum_mod4(s) == 1]
    B = [s for s in cand if coord_sum_mod4(s) == 3]
    return (2, 2, 2), A, B


def sublattice_tetrahedra(sites):
    adj = {s: set() for s in sites}
    for i, a in enumerate(sites):
        for b in sites[i+1:]:
            if sqdist(a, b) == 8:
                adj[a].add(b); adj[b].add(a)
    sl = sorted(sites); tets = []
    for a in sl:
        for b in adj[a]:
            if b <= a: continue
            for c in adj[a] & adj[b]:
                if c <= b: continue
                for d in adj[a] & adj[b] & adj[c]:
                    if d <= c: continue
                    tets.append((a, b, c, d))
    return tets


def parity_ok(chi, tets):
    for tet in tets:
        if sum(1 if chi[s] > 0 else 0 for s in tet) % 2 != 0:
            return False
    return True


def repair_to_parity(chi, tets, sites):
    """Case (iii): flip the minimal number of sites to reach nearest parity-
    satisfying config. For small tile we do a bounded search (Hamming radius
    up to 2) and take the first parity-satisfying neighbour; if none, return
    None (config cannot be repaired within radius -> not a program seed)."""
    if parity_ok(chi, tets):
        return chi
    site_list = list(sites)
    for r in (1, 2):
        for combo in itertools.combinations(site_list, r):
            c2 = dict(chi)
            for s in combo:
                c2[s] = -c2[s]
            if parity_ok(c2, tets):
                return c2
    return None


def t_closed(chi, sites, nbr, n_max=4):
    """Case (i): is chi T-closed (period<=n_max) under single-level T,
    deterministic branch, shell aggregate?"""
    cur = dict(chi)
    for n in range(1, n_max+1):
        cur = flop(cur, sites, set(sites), nbr, branch="deterministic",
                   parent_mode="shell", rng=np.random.default_rng(0))
        if equal_up_to_translation(cur, chi, sites):
            return True, n
    return False, None


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("="*64)
    print("STAGE 13v2 — program-zoo with repair+persistence (Paper 3 §2.5)")
    print("="*64 + "\n")

    p, A, B = build_tile()
    tile = A + B
    # minimal boundary shell: nearest in-sublattice neighbours of tile verts
    # kept small enough to enumerate the tile's own 8 dof exhaustively
    sites = sorted(tile)
    tets = sublattice_tetrahedra(sites)
    nbr = {s: [n for n in sites if sqdist(s, n) == 8] for s in sites}

    print(f"  tile sites: {len(sites)}  in-tile tetrahedra: {len(tets)}")
    print(f"  enumerating all 2^{len(sites)} = {2**len(sites)} tile configs\n")

    n_total = 0
    n_parity = 0           # parity-satisfying outright
    n_repairable = 0       # reach parity after repair
    n_program = 0          # parity (post-repair) AND T-closed
    program_sigs = set()
    closed_periods = []

    for bits in itertools.product((1, -1), repeat=len(sites)):
        n_total += 1
        chi = {s: b for s, b in zip(sites, bits)}
        if parity_ok(chi, tets):
            n_parity += 1
        chi_r = repair_to_parity(chi, tets, sites)
        if chi_r is None:
            continue
        n_repairable += 1
        closed, period = t_closed(chi_r, sites, nbr)
        if closed:
            n_program += 1
            closed_periods.append(period)
            pts = sorted(chi_r.keys())
            mn = tuple(min(s[i] for s in pts) for i in range(3))
            sig = frozenset(((s[0]-mn[0], s[1]-mn[1], s[2]-mn[2]),
                             1 if chi_r[s] > 0 else 0) for s in pts)
            program_sigs.add(sig)

    print(f"  total configs enumerated     : {n_total}")
    print(f"  parity-satisfying outright   : {n_parity}")
    print(f"  repairable to parity         : {n_repairable}")
    print(f"  PROGRAMS (parity & T-closed) : {n_program}")
    print(f"  distinct programs up to transl: {len(program_sigs)}")
    if closed_periods:
        from collections import Counter
        print(f"  closure periods observed     : {dict(Counter(closed_periods))}")

    print("\n" + "="*64)
    print("READING")
    print("="*64)
    print("  This uses the CORRECT §2.5 criterion (repair then test (i)-")
    print("  persistence), fixing the earlier zero-result harness. The tile's")
    print("  own 8 dof are enumerated exhaustively. The survivor count and its")
    print("  translation-distinct structure are reported; comparison to the")
    print("  claimed 4 logical × 24 O_h = 96 requires the FULL boundary shell")
    print("  (not just the 8 tile dof) and the O_h orbit count, which is the")
    print("  next extension. What is now SOLID: the program criterion is")
    print("  single-level and fully specified (§2.5 case i) — the earlier R3/R5")
    print("  'cross-level blocker' applied to the META-RULE form-invariance,")
    print("  NOT to the program-identity/zoo count, which is testable.")
