#!/usr/bin/env python3
"""
TMS Paper 5 App. B.4 — the 96-count, with full boundary shell + O_h orbits.
Final extension of the zoo enumeration (Stage 13v2 resolved the criterion;
this resolves the COUNT).

Strategy:
  - Build tile (8 verts) + ONE in-sublattice boundary shell.
  - Full tetrahedral parity constraints over tile+shell.
  - For each assignment of the constrained dof: repair to parity (§2.5 iii),
    test (i)-persistence (parity ∧ T-closed), collect programs.
  - Count programs up to the O_h point group (24 proper rotations, or 48 with
    reflections) acting about the tile centre (2,2,2), to test the claimed
    "24 orientations × 4 logical states = 96" factorization.

We report BOTH the raw program count and the orbit-reduced count, and check
whether raw / |stabilizer of a program| matches 96-type structure.
"""
import itertools
import numpy as np
from collections import Counter
from tms_dynamics import flop, equal_up_to_translation


def csum4(s): return (s[0]+s[1]+s[2]) % 4
def sq(a, b): return sum((a[i]-b[i])**2 for i in range(3))
def odd(s): return all(c % 2 == 1 for c in s)


def build_tile_shell(shell_radius=2):
    cand = [(i, j, k) for i in (1, 3) for j in (1, 3) for k in (1, 3)]
    A = [s for s in cand if csum4(s) == 1]
    B = [s for s in cand if csum4(s) == 3]
    tile = A + B
    shell = set()
    for v in tile:
        res = csum4(v)
        for o in itertools.product((-2, 0, 2), repeat=3):
            n = (v[0]+o[0], v[1]+o[1], v[2]+o[2])
            if sq(v, n) == 8 and odd(n) and csum4(n) == res:
                shell.add(n)
    shell -= set(tile)
    return (2, 2, 2), A, B, tile, sorted(shell)


def tetrahedra(sites):
    adj = {s: set() for s in sites}
    for i, a in enumerate(sites):
        for b in sites[i+1:]:
            if sq(a, b) == 8:
                adj[a].add(b); adj[b].add(a)
    sl = sorted(sites); T = []
    for a in sl:
        for b in adj[a]:
            if b <= a: continue
            for c in adj[a] & adj[b]:
                if c <= b: continue
                for d in adj[a] & adj[b] & adj[c]:
                    if d <= c: continue
                    T.append((a, b, c, d))
    return T


def parity_ok(chi, T):
    return all(sum(1 if chi[s] > 0 else 0 for s in t) % 2 == 0 for t in T)


def repair(chi, T, sites, max_r=2):
    if parity_ok(chi, T):
        return chi
    for r in (1, 2):
        for combo in itertools.combinations(sites, r):
            c2 = dict(chi)
            for s in combo: c2[s] = -c2[s]
            if parity_ok(c2, T):
                return c2
    return None


def t_closed(chi, sites, nbr, n_max=4):
    cur = dict(chi)
    for n in range(1, n_max+1):
        cur = flop(cur, sites, set(sites), nbr, branch="deterministic",
                   parent_mode="shell", rng=np.random.default_rng(0))
        if equal_up_to_translation(cur, chi, sites):
            return True
    return False


# ---- O_h group: 48 signed permutation matrices with det = ±1 ----
def oh_group():
    mats = []
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((1, -1), repeat=3):
            M = np.zeros((3, 3), dtype=int)
            for i in range(3):
                M[i, perm[i]] = signs[i]
            mats.append(M)
    return mats  # 48 elements (full O_h with reflections)


def apply_oh(M, chi, centre):
    c = np.array(centre)
    out = {}
    for s, v in chi.items():
        p = c + M @ (np.array(s) - c)
        out[tuple(int(x) for x in p)] = v
    return out


def canon(chi):
    pts = sorted(chi.keys())
    mn = tuple(min(s[i] for s in pts) for i in range(3))
    return frozenset(((s[0]-mn[0], s[1]-mn[1], s[2]-mn[2]),
                      1 if chi[s] > 0 else 0) for s in pts)


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("="*64)
    print("STAGE 13v3 — 96-count: full shell + O_h orbits (App. B.4)")
    print("="*64 + "\n")

    p, A, B, tile, shell = build_tile_shell()
    sites = sorted(tile + shell)
    T = tetrahedra(sites)
    nbr = {s: [n for n in sites if sq(s, n) == 8] for s in sites}
    print(f"  tile: {len(tile)}  shell: {len(shell)}  total: {len(sites)}  "
          f"tetrahedra: {len(T)}")

    # Enumerating 2^len(sites) is too big if shell is large; cap by fixing
    # shell to the parity-forced ground and enumerating tile + a slice.
    n_sites = len(sites)
    if n_sites <= 20:
        enum = sites; fixed = []
    else:
        enum = tile + shell[:max(0, 20-len(tile))]
        fixed = shell[20-len(tile):] if len(tile) < 20 else shell
    print(f"  enumerating {len(enum)} dof (2^{len(enum)}="
          f"{2**len(enum)}), {len(fixed)} fixed\n")

    base = {s: 1 for s in fixed}
    programs = []
    raw_sigs = set()
    for bits in itertools.product((1, -1), repeat=len(enum)):
        chi = dict(base)
        for s, b in zip(enum, bits): chi[s] = b
        chi_r = repair(chi, T, sites)
        if chi_r is None: continue
        if t_closed(chi_r, sites, nbr):
            programs.append(chi_r)
            raw_sigs.add(canon(chi_r))

    print(f"  raw programs (post-repair, T-closed): {len(programs)}")
    print(f"  distinct up to translation          : {len(raw_sigs)}")

    # O_h orbit reduction
    G = oh_group()
    orbit_reps = set()
    seen = set()
    for sig in raw_sigs:
        if sig in seen:
            continue
        # build chi from sig
        chi = {(s[0], s[1], s[2]): (1 if v > 0 else -1) for (s, v) in sig}
        orbit = set()
        for M in G:
            orbit.add(canon(apply_oh(M, chi, (0, 0, 0))))
        # mark whole orbit seen; pick one rep
        unseen_before = orbit & raw_sigs
        seen |= unseen_before
        orbit_reps.add(min(orbit, key=lambda x: sorted(x)))

    print(f"  distinct up to O_h (48) + translation: {len(orbit_reps)}")

    print("\n" + "="*64)
    print("VERDICT on the 96-count (App. B.4)")
    print("="*64)
    print(f"  raw program count            : {len(programs)}")
    print(f"  translation-distinct         : {len(raw_sigs)}")
    print(f"  O_h + translation distinct   : {len(orbit_reps)}")
    print(f"  corpus claim: 96 = 4 logical × 24 O_h orientations")
    print(f"  If translation-distinct ≈ 96 and O_h-distinct ≈ 4, the claimed")
    print(f"  factorization holds. Otherwise, the count differs and B.4's 96")
    print(f"  is not reproduced by this (single in-sublattice shell) model —")
    print(f"  reported honestly either way.")
