#!/usr/bin/env python3
"""
TMS Paper 5 Lemma A — DERIVATION of the spinor character of the (psi_A, psi_B)
sublattice doublet. The single most load-bearing open claim: the matter sector
(fermions, generations, Dirac structure, §8.4) rests entirely on this doublet
being a genuine SPINOR (SU(2) double-cover) rather than a trivial 2-vector
(SO(3)).

THE TEST (non-circular, following the corpus's own graphene analogy):
In graphene, the two-sublattice (A/B) structure produces a BERRY PHASE of pi
around each Dirac point — and that pi Berry phase IS the spinor sign (rotating
the pseudospin by 2pi gives -1). So the genuine test of "is the A/B doublet a
spinor?" is:

  1. Build the substrate's effective 2-band Bloch Hamiltonian H(k) on the
     A/B doublet over the FCC Brillouin zone, with inter-sublattice coupling
     set by the actual A<->B nearest-neighbour geometry of the stella-octangula
     tile (NOT assumed — read off the lattice).
  2. Find the band-crossing (Dirac/Weyl) points where the two bands touch.
  3. Transport the eigenstate around a closed loop encircling a crossing and
     compute the Berry phase.
  4. Berry phase = pi (mod 2pi)  -> the doublet is a SPINOR (claim DERIVED).
     Berry phase = 0             -> trivial 2-vector (claim FAILS).

This is the same diagnostic that establishes graphene's Dirac fermions; applying
it to the FCC+stella geometry either derives or refutes the TMS claim.

METHOD NOTE: the substrate Hamiltonian is a tight-binding model on the A/B
sublattices with hopping along the actual A-B nearest-neighbour bonds. The
two sublattices A (sum=1 mod4) and B (sum=3 mod4) of the level-1 (all-odd)
lattice are interpenetrating FCC lattices; an A site's nearest B neighbours
are at squared distance 4 (the all-odd simple-cubic NN). We build the
inter-sublattice structure factor from these bonds.
"""
import numpy as np
import itertools


# ----------------------------------------------------------------------
# Geometry: A and B sublattices of the level-1 (all-odd) lattice
# ----------------------------------------------------------------------
def csum4(s): return (s[0] + s[1] + s[2]) % 4


def ab_bonds():
    """Nearest A<->B bonds. A site (sum=1) and B site (sum=3) on the all-odd
    lattice: nearest neighbours differ by sum 2 (mod 4). The all-odd lattice
    has simple-cubic NN at squared distance 4 (steps of (±2,0,0) etc.) — but
    those preserve sum mod 4 parity? (2,0,0): sum changes by 2 -> flips 1<->3.
    YES. So A-B nearest bonds are the 6 cubic directions (±2,0,0),(0,±2,0),
    (0,0,±2)."""
    return [(2, 0, 0), (-2, 0, 0), (0, 2, 0), (0, -2, 0), (0, 0, 2), (0, 0, -2)]


def verify_bond_geometry():
    """Confirm the (±2,0,0)-type steps connect A(sum=1) to B(sum=3)."""
    A_site = (1, 1, 1)  # sum=3 -> actually B. pick sum=1:
    A_site = (1, 1, 3)  # sum=5=1 mod4 -> A
    assert csum4(A_site) == 1
    nbrs = [tuple(A_site[i] + d[i] for i in range(3)) for d in ab_bonds()]
    all_B = all(csum4(n) == 3 for n in nbrs)
    return all_B, A_site, nbrs


# ----------------------------------------------------------------------
# Bloch Hamiltonian on the A/B doublet
# ----------------------------------------------------------------------
def structure_factor(k, bonds):
    """f(k) = sum over A->B bonds of exp(i k·delta). The off-diagonal
    inter-sublattice hopping."""
    f = 0j
    for d in bonds:
        f += np.exp(1j * (k[0]*d[0] + k[1]*d[1] + k[2]*d[2]))
    return f


def bloch_H(k, bonds):
    """2-band Bloch Hamiltonian:
        H(k) = [[0, f(k)], [f*(k), 0]]
    inter-sublattice hopping only (chiral/bipartite symmetry, as in graphene).
    Bands: E = ±|f(k)|. Crossings where f(k)=0."""
    f = structure_factor(k, bonds)
    return np.array([[0, f], [np.conj(f), 0]], dtype=complex)


def lower_band_state(k, bonds):
    """Eigenvector of the lower band (E = -|f|)."""
    H = bloch_H(k, bonds)
    w, v = np.linalg.eigh(H)
    return v[:, 0]  # lowest eigenvalue


# ----------------------------------------------------------------------
# Find a band-crossing (Dirac point): f(k) = 0
# ----------------------------------------------------------------------
def find_crossing(bonds):
    """f(k) = 2[cos(2kx)+cos(2ky)+cos(2kz)] (from the 6 cubic bonds).
    Wait: sum of exp(i k·(±2 e_j)) = 2cos(2k_j) summed over j.
    f=0 where cos(2kx)+cos(2ky)+cos(2kz)=0. A simple crossing point:
    kx s.t. 2kx=pi/2 -> kx=pi/4 won't zero it alone; need the sum=0.
    Take (kx,ky,kz) with cos(2kx)=cos(2ky)=cos(2kz)=0 -> 2k_j=pi/2 ->
    k_j=pi/4 gives cos=0 each -> sum=0. So k*=(pi/4,pi/4,pi/4)."""
    kstar = np.array([np.pi/4, np.pi/4, np.pi/4])
    f = structure_factor(kstar, bonds)
    return kstar, f


# ----------------------------------------------------------------------
# Berry phase around a loop encircling the crossing
# ----------------------------------------------------------------------
def berry_phase_loop(center, bonds, radius=0.15, n_pts=400, plane=(0, 1)):
    """Transport the lower-band state around a circle of given radius in the
    plane spanned by axes plane=(i,j), centered at `center`. Berry phase =
    -Im sum log <psi_n|psi_{n+1}>."""
    i, j = plane
    states = []
    for t in np.linspace(0, 2*np.pi, n_pts, endpoint=False):
        k = np.array(center, dtype=float)
        k[i] += radius * np.cos(t)
        k[j] += radius * np.sin(t)
        states.append(lower_band_state(k, bonds))
    phase = 0j
    for n in range(n_pts):
        overlap = np.vdot(states[n], states[(n+1) % n_pts])
        phase += np.log(overlap / abs(overlap))
    berry = -np.imag(phase)
    return berry


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25", precision=4, suppress=True)
    print("="*64)
    print("DERIVATION — spinor character of the (psi_A, psi_B) doublet")
    print("  (Berry-phase test, following the corpus's graphene analogy)")
    print("="*64 + "\n")

    bonds = ab_bonds()

    # Step 0: verify the A-B bond geometry is read from the lattice, not assumed
    okgeom, Asite, nbrs = verify_bond_geometry()
    print("STEP 0 — A<->B bond geometry (from the lattice)")
    print(f"  A site {Asite} (sum mod4 = 1)")
    print(f"  its 6 nearest neighbours via (±2,0,0)-type steps:")
    print(f"    {nbrs}")
    print(f"  all on B sublattice (sum mod4 = 3): {okgeom}")
    print(f"  -> inter-sublattice hopping is the 6 cubic bonds. (geometry-set)\n")

    # Step 1-2: the Hamiltonian and its crossing
    print("STEP 1-2 — Bloch Hamiltonian and band-crossing")
    print("  H(k) = [[0, f(k)],[f*(k), 0]],  f(k)=2[cos2kx+cos2ky+cos2kz]")
    kstar, fstar = find_crossing(bonds)
    print(f"  candidate Dirac point k* = (pi/4,pi/4,pi/4)")
    print(f"  f(k*) = {fstar:.6f}  -> |f(k*)| = {abs(fstar):.2e}")
    crossing = abs(fstar) < 1e-9
    print(f"  bands touch at k* (f=0): {crossing}\n")

    # Step 3-4: Berry phase
    print("STEP 3-4 — Berry phase around the crossing")
    berries = {}
    for plane, nm in [((0, 1), "kx-ky"), ((1, 2), "ky-kz"), ((0, 2), "kx-kz")]:
        b = berry_phase_loop(kstar, bonds, plane=plane)
        berries[nm] = b
        # normalize to (-pi,pi]
        bn = (b + np.pi) % (2*np.pi) - np.pi
        print(f"  loop in {nm} plane: Berry phase = {b:.4f} rad "
              f"= {bn:.4f} (mod 2pi)  [{bn/np.pi:.3f} pi]")

    print("\n" + "="*64)
    print("VERDICT")
    print("="*64)
    # spinor iff Berry phase = pi (mod 2pi) on a loop around the crossing
    vals = [abs((b % (2*np.pi)) - np.pi) for b in berries.values()]
    is_pi = any(v < 0.3 for v in vals)  # close to pi on at least one plane
    print(f"  Berry phases (mod 2pi): "
          f"{[round((b%(2*np.pi))/np.pi,3) for b in berries.values()]} × pi")
    if is_pi:
        print("  At least one encircling loop carries Berry phase pi.")
        print("  => the doublet acquires -1 under 2pi pseudospin rotation:")
        print("     SPINOR CHARACTER DERIVED. The matter sector's foundational")
        print("     claim (Lemma A) is supported by direct computation on the")
        print("     FCC+stella geometry — same diagnostic as graphene's Dirac")
        print("     fermions. NOT assumed.")
    else:
        print("  No encircling loop carries Berry phase pi.")
        print("  => the doublet does NOT exhibit the spinor sign on this model;")
        print("     the claim is NOT supported as stated and needs revision.")
