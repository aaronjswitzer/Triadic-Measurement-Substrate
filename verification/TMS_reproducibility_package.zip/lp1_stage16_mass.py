#!/usr/bin/env python3
"""
TMS mass spectrum — FIRST REAL COMPUTATION (honest, exploratory).

Hypothesis (from "matter = frozen information, frozen by measuring"):
  mass = rate of self-measurement; a massive particle is a STANDING PROGRAM that
  re-confirms itself with period T_0 = n * t_flop; mass ~ f(n). The mass SPECTRUM
  is the set of stable standing-program periods under the Flop Operator T.

This stage ENUMERATES standing programs on a small FCC patch and finds their
periods under the real (deterministic) T from tms_dynamics. It reports the
period structure that actually exists — WITHOUT grabbing numbers or assuming
m ~ 1/n. The goal is to see whether the periods are rich enough to plausibly
hold a realistic spectrum, or whether the idea hits a wall.

A "standing program" here: a finite set of confirmed sites on an FCC patch with
assigned chi in {+1,-1}, evolved by T restricted to that patch (fixed support,
the pattern must re-confirm ON its own cells — a localized self-sustaining loop).
We look for configurations C with T^n[C] = C (return), classify by minimal n.

HONEST SCOPE: this is a first pass on a small patch with the deterministic
branch. It tests STRUCTURE (what periods exist, how many, their distribution),
not the actual particle masses. Reported as exploratory.
"""
import itertools
import numpy as np
from collections import Counter, defaultdict

# reuse the real T geometry
def fcc_nn_offsets():
    return [o for o in itertools.product((-1, 0, 1), repeat=3)
            if o[0]**2 + o[1]**2 + o[2]**2 == 2]
NN = fcc_nn_offsets()


def neighbors(site, support):
    i, j, k = site
    return [(i+a, j+b, k+c) for (a, b, c) in NN if (i+a, j+b, k+c) in support]


def step_deterministic(chi, support):
    """One flop on a FIXED support: each site re-resolves from its confirmed
    neighbours' mean polarization. Deterministic branch (sign), ties -> keep.
    This is the 'standing program re-confirms itself' dynamic: the pattern's
    own cells re-measure each other."""
    new = {}
    for s in support:
        nb = neighbors(s, support)
        if not nb:
            new[s] = chi[s]  # isolated: holds
            continue
        m = sum(chi[n] for n in nb) / len(nb)
        if m > 0:
            new[s] = 1
        elif m < 0:
            new[s] = -1
        else:
            new[s] = chi[s]  # tie: hold (deterministic, no coin here)
    return new


def find_period(chi0, support, max_n=64):
    """Evolve; return minimal n with T^n[C]=C (period), or None if no return
    within max_n."""
    seen = {}
    cur = dict(chi0)
    for t in range(max_n + 1):
        key = tuple(cur[s] for s in support)
        if key in seen:
            return t - seen[key], seen[key]  # (period, preperiod)
        seen[key] = t
        cur = step_deterministic(cur, support)
    return None, None


def small_fcc_patch(radius=2):
    """Sites i+j+k even within a cube of given radius around origin."""
    R = radius
    return [(i, j, k) for i in range(-R, R+1) for j in range(-R, R+1)
            for k in range(-R, R+1) if (i+j+k) % 2 == 0]


def enumerate_periods(support, n_samples=4000, seed=0):
    """Sample chi-configurations on the support, find their periods."""
    rng = np.random.default_rng(seed)
    period_counts = Counter()
    period_examples = {}
    N = len(support)
    for _ in range(n_samples):
        chi = {s: int(rng.choice([-1, 1])) for s in support}
        period, preperiod = find_period(chi, support)
        if period is not None:
            period_counts[period] += 1
            if period not in period_examples:
                period_examples[period] = dict(chi)
    return period_counts, period_examples


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("="*66)
    print("STAGE 16 — mass spectrum: standing-program periods under real T")
    print("="*66 + "\n")

    for radius in [1, 2]:
        support = small_fcc_patch(radius)
        print(f"--- FCC patch radius {radius}: {len(support)} sites ---")
        if len(support) > 20:
            print(f"    (sampling configurations; 2^{len(support)} full space too big)")
        pc, ex = enumerate_periods(support, n_samples=6000)
        total = sum(pc.values())
        print(f"    stable (returning) configs found: {total}")
        print(f"    PERIOD SPECTRUM (period : count : fraction):")
        for p in sorted(pc):
            print(f"      period {p:3d} : {pc[p]:5d} : {pc[p]/total:.3f}")
        # attractor periods = the stable "masses"
        print(f"    distinct stable periods: {sorted(pc.keys())}")
        print()

    print("="*66)
    print("INTERPRETATION (honest)")
    print("="*66)
    print("The distinct stable periods are the candidate 'mass levels' (each a")
    print("standing program that re-confirms with that period). What matters for")
    print("the hypothesis:")
    print("  - Are there MULTIPLE distinct stable periods? (need >1 for a spectrum)")
    print("  - Is the set STRUCTURED (specific periods, not all n)?")
    print("  - Do the periods form a pattern that COULD map to mass ratios?")
    print("This is STRUCTURE only — NOT a claim about actual particle masses.")
    print("Whether these periods map to real masses is a separate, harder step")
    print("and is NOT attempted here. Reporting what the machinery actually gives.")
