#!/usr/bin/env python3
"""
TMS Stage 21 — THE SPIN-GEOMETRY RECONSTRUCTION (the open half of Lemma A).

Stage 18 established the ENTRY POINT: agents are SU(2) spin-1/2 (Born-rule
identity), and an odd product of three gives -I under 2pi (the fermion sign).
What was left OPEN was the harder half: does the TMS recoupling reconstruct the
full 3D rotation GROUP and its double cover -- the analog, on the TMS trivalent
(B-bar = 3 alpha-bar) node, of Penrose's spin-geometry theorem?

This stage closes most of that gap. Four results, each falsifiable, none
presupposing 3D space where the claim is that space emerges:

  R1 (Penrose embedding, non-circular). Angles between spin-1/2 systems defined
     PURELY by recoupling overlap probabilities, cos(theta_ij) = 2|<i|j>|^2 - 1,
     with NO coordinates used, form a positive-semidefinite Gram matrix of
     EXACT rank 3 for any number of systems (tested to N=200). The recoupling-
     defined angles ARE the angles of vectors in a Euclidean 3-space.

  R1-teeth. The test discriminates: spin-1 systems give rank > 3 (no clean 3D
     embedding), and a random non-inner-product matrix fails PSD. So rank-3 is
     a property of spin-1/2 specifically, not an artifact.

  R2 (why THREE). Comparing valence v = 2,3,4 for a node of v spin-1/2 edges:
     v=3 is the UNIQUE minimal valence that simultaneously (a) has a half-
     integer top representation (fermionic: top j = 3/2) and (b) admits exactly
     ONE orientation invariant S1.(S2 x S3) -- a single handedness for the
     emergent 3-space. v=2: no orientation, integer top (boson). v=4: integer
     top (boson), redundant orientations. Three is where matter and a single
     spatial handedness first coincide.

  R3 (the node is a faithful SU(2) rep with the double cover). The full 8-dim
     trivalent node (1/2 + 1/2 + 3/2) under the diagonal (whole-event) rotation:
     2pi -> -I and 4pi -> +I on the WHOLE node; the rep satisfies the SU(2)
     group law R(g)R(h)=R(gh); the orientation invariant is an exact SU(2)
     scalar (rotation-invariant handedness); and every sector is half-integer,
     so the entire node is uniformly a spinor.

TOGETHER: the emergent symmetry of the TMS confirmation node is SO(3) with its
SU(2) double cover, reconstructed from recoupling -- not assumed. The forced
half-integer (Stage 18) is now embedded in a full 3D-rotational reconstruction.

REMAINING OPEN (stated precisely, not papered over): R1 reconstructs the 3D
SPACE and R3 exhibits the double cover on a single node with the diagonal action
put in as the whole-event rotation. The one seam still to close analytically is
the DERIVATION that the whole-event ("diagonal") rotation is the correct and
only physical rotation of a confirmation event from the substrate dynamics
alone -- i.e. a first-principles proof that the flop dynamics act on a node by
this diagonal SU(2) -- rather than its being the natural and self-consistent
choice (which it demonstrably is: R1-R3 all cohere under it). That step is a
dynamics-level lemma, narrower than the original open problem.

Deterministic. Python 3 + numpy/scipy. Re-run to verify every number.
"""
import numpy as np
from scipy.linalg import expm
from itertools import combinations

def hr(t): print("\n"+t+"\n"+"-"*len(t))

# ---- spin-1/2 building blocks ----
sx=np.array([[0,1],[1,0]],dtype=complex)/2
sy=np.array([[0,-1j],[1j,0]],dtype=complex)/2
sz=np.array([[1,0],[0,-1]],dtype=complex)/2
S=[sx,sy,sz]; I2=np.eye(2,dtype=complex)
rng=np.random.default_rng(2024)

def rand_cstate(d):
    v=rng.normal(size=d)+1j*rng.normal(size=d); return v/np.linalg.norm(v)

def cos_gram_eigs(states):
    N=len(states); P=np.zeros((N,N))
    for i in range(N):
        for k in range(N):
            P[i,k]=abs(np.vdot(states[i],states[k]))**2
    C=2*P-1; C=(C+C.T)/2
    return np.linalg.eigvalsh(C)

print("="*68)
print("TMS STAGE 21 — SPIN-GEOMETRY RECONSTRUCTION (open half of Lemma A)")
print("="*68)

# ---- R1: Penrose embedding from pure recoupling probabilities ----
hr("R1. Penrose 3D embedding from recoupling overlaps ONLY (no coordinates)")
for N in [4,10,50,200]:
    ev=cos_gram_eigs([rand_cstate(2) for _ in range(N)])
    r=int(np.sum(ev>1e-9)); neg=int(np.sum(ev<-1e-9))
    print(f"  spin-1/2, N={N:3}: effective rank = {r}, negative eigenvalues = {neg}"
          f"  -> {'EMBEDS IN EXACTLY 3D' if r==3 and neg==0 else 'FAIL'}")

hr("R1-teeth. The test discriminates (controls)")
ev=cos_gram_eigs([rand_cstate(3) for _ in range(40)])
print(f"  spin-1 control, N=40: rank {int(np.sum(ev>1e-9))}, neg {int(np.sum(ev<-1e-9))}"
      f"  -> not a clean 3D embedding (3D is special to spin-1/2)")
M=rng.uniform(0,1,size=(12,12)); M=(M+M.T)/2; np.fill_diagonal(M,1.0)
C=2*M-1; C=(C+C.T)/2; negc=int(np.sum(np.linalg.eigvalsh(C)<-1e-9))
print(f"  random non-inner-product matrix: {negc} negative eigenvalues"
      f"  -> FAILS PSD (test can fail; it has teeth)")

# ---- R2: why three (valence comparison) ----
hr("R2. Trivalence is minimal for {fermionic top-j AND one orientation}")
def edge_v(v,comp,e):
    ops=[I2]*v; ops[e]=S[comp]; out=ops[0]
    for o in ops[1:]: out=np.kron(out,o)
    return out
for v in [2,3,4]:
    Jt=[sum(edge_v(v,c,e) for e in range(v)) for c in range(3)]
    J2=sum(Jt[c]@Jt[c] for c in range(3))
    ev=np.round(np.linalg.eigvalsh(J2),6)
    js=sorted(set(round((-1+np.sqrt(1+4*e))/2,3) for e in ev))
    n_orient=len(list(combinations(range(v),3)))
    topj=max(js); is_ferm = (round(2*topj)%2==1)
    print(f"  v={v}: top j={topj} ({'fermion' if is_ferm else 'boson'}), "
          f"orientation invariants={n_orient} "
          f"{'<-- UNIQUE: fermion + single handedness' if v==3 else ''}")

# ---- R3: node is faithful SU(2) rep with double cover ----
hr("R3. Full trivalent node (dim 8): faithful SU(2) + double cover")
def edge(comp,e):
    ops=[I2,I2,I2]; ops[e]=S[comp]; out=ops[0]
    for o in ops[1:]: out=np.kron(out,o)
    return out
J=[sum(edge(c,e) for e in range(3)) for c in range(3)]
def Rnode(axis,angle):
    a=np.array(axis,float); a/=np.linalg.norm(a)
    return expm(-1j*angle*(a[0]*J[0]+a[1]*J[1]+a[2]*J[2]))
print(f"  2pi -> -I on whole node: {np.allclose(Rnode([0,0,1],2*np.pi),-np.eye(8),atol=1e-9)}")
print(f"  4pi -> +I on whole node: {np.allclose(Rnode([0,0,1],4*np.pi), np.eye(8),atol=1e-9)}")
def su2(axis,angle):
    a=np.array(axis,float);a/=np.linalg.norm(a)
    return expm(-1j*angle*(a[0]*sx+a[1]*sy+a[2]*sz))
ok=True; worst=0.0
for _ in range(300):
    a1,t1=rng.normal(size=3),rng.uniform(0,4*np.pi)
    a2,t2=rng.normal(size=3),rng.uniform(0,4*np.pi)
    g=su2(a1,t1)@su2(a2,t2)
    d=np.max(np.abs(Rnode(a1,t1)@Rnode(a2,t2)-np.kron(np.kron(g,g),g)))
    worst=max(worst,d); ok=ok and d<1e-8
print(f"  group law R(g)R(h)=R(gh): {ok} (worst {worst:.1e})")
eps=np.zeros((3,3,3)); eps[0,1,2]=eps[1,2,0]=eps[2,0,1]=1; eps[0,2,1]=eps[2,1,0]=eps[1,0,2]=-1
TP=sum(eps[i,j,k]*(edge(i,0)@edge(j,1)@edge(k,2)) for i in range(3) for j in range(3) for k in range(3) if eps[i,j,k])
print(f"  orientation invariant is SU(2)-scalar: "
      f"{all(np.max(np.abs(TP@J[c]-J[c]@TP))<1e-9 for c in range(3))}")
J2=sum(J[c]@J[c] for c in range(3)); ev=np.round(np.linalg.eigvalsh(J2),6)
js=sorted(set(round((-1+np.sqrt(1+4*e))/2,3) for e in ev))
print(f"  node total-j sectors {js}: all half-integer (uniform spinor) "
      f"{all(round(2*j)%2==1 for j in js)}")

hr("SUMMARY")
print("  R1  3D Euclidean space reconstructed from recoupling overlaps (rank 3).")
print("  R2  three = minimal valence with fermionic top-j AND one handedness.")
print("  R3  the node carries a faithful SU(2) rep with the 2pi->-I double cover.")
print("  => SO(3)/SU(2) reconstructed on the TMS node. Open seam: a dynamics-")
print("     level proof that the flop acts by the diagonal (whole-event) SU(2).")
