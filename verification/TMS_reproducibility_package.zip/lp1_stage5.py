#!/usr/bin/env python3
"""
TMS Paper 5, Appendix E, Stage 5
Per-Sublattice FCC Verification at Level 1.

Storage convention (Paper 5 S6.1, App. E.1):
  - level-0 agent FCC: integer sites with i+j+k EVEN.
  - each hierarchical level scales spacing by x2.
  - level-1 sites: ALL-ODD-coord integers.
  - level-2 sites: ALL-EVEN-coord integers.

Stage 5 hypothesis:
  All-odd-coord level-1 sites split by sum-mod-4 into two interpenetrating
  FCC sublattices:
        A: sum == 1 (mod 4)
        B: sum == 3 (mod 4)
  Each sublattice has FCC nearest-neighbour distance 2*sqrt(2) storage units
  (squared distance = 8), supports tetrahedral closure (4-site clusters at
  mutual NN squared-distance 8), and an [[4,2,2]] stabilizer structure
  whose F2 null-space dimension scales as k = 3n with level-local depth
  n = (L_box - 1)/2.

We reproduce the exact tables in App. E.2 and check them.
"""

import itertools
import numpy as np


# ----------------------------------------------------------------------
# Lattice generation
# ----------------------------------------------------------------------
def level1_sites(L_box):
    """All-odd-coord integer sites in [1, L_box]^3."""
    rng = range(1, L_box + 1)
    return [(i, j, k) for i in rng for j in rng for k in rng
            if i % 2 == 1 and j % 2 == 1 and k % 2 == 1]


def sublattice(sites, residue):
    """Sites whose coordinate-sum == residue (mod 4)."""
    return [s for s in sites if (s[0] + s[1] + s[2]) % 4 == residue]


# ----------------------------------------------------------------------
# Nearest-neighbour structure
# ----------------------------------------------------------------------
def sq(a, b):
    return (a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2


def nn_pairs(sites, d2=8):
    """All unordered NN pairs at squared distance d2."""
    pairs = []
    n = len(sites)
    for i in range(n):
        for j in range(i+1, n):
            if sq(sites[i], sites[j]) == d2:
                pairs.append((i, j))
    return pairs


def max_coordination(sites, d2=8):
    """Maximum NN count over all sites (interior coordination)."""
    if not sites:
        return 0
    counts = [0]*len(sites)
    for (i, j) in nn_pairs(sites, d2):
        counts[i] += 1
        counts[j] += 1
    return max(counts)


# ----------------------------------------------------------------------
# Tetrahedra: 4-cliques in the NN graph (all 6 edges at squared dist 8)
# ----------------------------------------------------------------------
def find_tetrahedra(sites, d2=8):
    """All 4-site clusters with all 6 mutual distances squared == d2."""
    n = len(sites)
    adj = [set() for _ in range(n)]
    for (i, j) in nn_pairs(sites, d2):
        adj[i].add(j)
        adj[j].add(i)

    tets = []
    # enumerate 4-cliques
    for a in range(n):
        for b in adj[a]:
            if b <= a:
                continue
            common_ab = adj[a] & adj[b]
            for c in common_ab:
                if c <= b:
                    continue
                common_abc = common_ab & adj[c]
                for d in common_abc:
                    if d <= c:
                        continue
                    tets.append((a, b, c, d))
    return tets


# ----------------------------------------------------------------------
# [[4,2,2]] stabilizer null-space: F2 dimension of the site-tet parity map
# ----------------------------------------------------------------------
def f2_nullspace_dim(sites, tets):
    """
    Parity matrix M (tets x sites): M[t, s] = 1 if site s is a vertex of
    tetrahedron t. The stabilizer-satisfying configuration space is the
    F2 null space of M acting on site-assignments; its dimension is
        k = (#sites) - rank_F2(M).
    """
    n_sites = len(sites)
    if not tets:
        return 0
    M = np.zeros((len(tets), n_sites), dtype=np.uint8)
    idx = {s: i for i, s in enumerate(sites)}
    # tets store site indices already
    for t, tet in enumerate(tets):
        for s in tet:
            M[t, s] = 1
    rank = gf2_rank(M)
    return n_sites - rank


def gf2_rank(M):
    """Rank over GF(2) by Gaussian elimination."""
    A = M.copy().astype(np.uint8) % 2
    rows, cols = A.shape
    r = 0
    for c in range(cols):
        # find pivot
        piv = -1
        for i in range(r, rows):
            if A[i, c]:
                piv = i
                break
        if piv == -1:
            continue
        A[[r, piv]] = A[[piv, r]]
        # eliminate
        for i in range(rows):
            if i != r and A[i, c]:
                A[i] ^= A[r]
        r += 1
        if r == rows:
            break
    return r


# ----------------------------------------------------------------------
# Centroids and inversion partnership
# ----------------------------------------------------------------------
def centroid(sites, tet):
    pts = np.array([sites[i] for i in tet], dtype=float)
    return tuple(np.round(pts.mean(axis=0), 6))


def is_inversion_partner(sitesA, tetA, sitesB, tetB):
    """True if tetB is the exact point-inversion of tetA through their
    shared centroid: for each vertex v in A, 2*centroid - v is in B."""
    cA = np.array(centroid(sitesA, tetA))
    cB = np.array(centroid(sitesB, tetB))
    if not np.allclose(cA, cB):
        return False
    setB = {tuple(np.array(sitesB[i], dtype=float)) for i in tetB}
    for i in tetA:
        v = np.array(sitesA[i], dtype=float)
        mirror = tuple(np.round(2*cA - v, 6))
        if mirror not in setB:
            return False
    return True


# ----------------------------------------------------------------------
# Drivers
# ----------------------------------------------------------------------
def stage5_structural_table():
    print("STAGE 5 -- Per-sublattice structural numbers (level 1)")
    print(f"{'Lbox':>4} | {'A:sites':>7} {'A:tets':>6} {'A:k':>3} {'A:maxNN':>7} "
          f"| {'B:sites':>7} {'B:tets':>6} {'B:k':>3} {'B:maxNN':>7}")
    rows = {}
    for L in (3, 5, 7, 9, 11):
        s = level1_sites(L)
        A = sublattice(s, 1)
        B = sublattice(s, 3)
        tA = find_tetrahedra(A)
        tB = find_tetrahedra(B)
        kA = f2_nullspace_dim(A, tA)
        kB = f2_nullspace_dim(B, tB)
        mA = max_coordination(A)
        mB = max_coordination(B)
        rows[L] = (len(A), len(tA), kA, mA, len(B), len(tB), kB, mB)
        print(f"{L:>4} | {len(A):>7} {len(tA):>6} {kA:>3} {mA:>7} "
              f"| {len(B):>7} {len(tB):>6} {kB:>3} {mB:>7}")
    return rows


def stage5_inversion_table():
    print("\nSTAGE 5 -- Inversion-partnership (level 1)")
    print(f"{'Lbox':>4} | {'Acent':>6} {'Bcent':>6} {'Shared':>6} "
          f"{'A-only':>6} {'B-only':>6} | {'invVerified':>12}")
    rows = {}
    for L in (5, 7, 9):
        s = level1_sites(L)
        A = sublattice(s, 1)
        B = sublattice(s, 3)
        tA = find_tetrahedra(A)
        tB = find_tetrahedra(B)
        cA = {centroid(A, t): t for t in tA}
        cB = {centroid(B, t): t for t in tB}
        shared = set(cA) & set(cB)
        a_only = set(cA) - set(cB)
        b_only = set(cB) - set(cA)
        # sample 3 shared centroids, verify exact inversion partnership
        sample = list(shared)[:3]
        verified = 0
        for c in sample:
            if is_inversion_partner(A, cA[c], B, cB[c]):
                verified += 1
        rows[L] = (len(cA), len(cB), len(shared), len(a_only), len(b_only),
                   verified, len(sample))
        print(f"{L:>4} | {len(cA):>6} {len(cB):>6} {len(shared):>6} "
              f"{len(a_only):>6} {len(b_only):>6} | {verified:>5}/{len(sample):<6}")
    return rows


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    r1 = stage5_structural_table()
    r2 = stage5_inversion_table()

    # ---- check against Appendix E.2 claimed tables ----
    print("\n" + "="*60)
    print("CHECK vs Appendix E.2 claimed numbers")
    print("="*60)

    # claimed: Lbox -> (A_sites, A_tets, A_k, A_maxNN, B_sites, B_tets, B_k, B_maxNN)
    claimed_struct = {
        3:  (4,   1,   3,  3,  4,   1,   3,  3),
        5:  (13,  8,   6,  12, 14,  8,   6,  8),
        7:  (32,  27,  9,  12, 32,  27,  9,  12),
        9:  (62,  64,  12, 12, 63,  64,  12, 12),
        11: (108, 125, 15, 12, 108, 125, 15, 12),
    }
    ok = True
    for L, claim in claimed_struct.items():
        got = r1[L]
        match = (got == claim)
        ok = ok and match
        flag = "OK " if match else "*** MISMATCH ***"
        print(f"  L={L:<2} {flag}")
        if not match:
            print(f"      claimed: {claim}")
            print(f"      got    : {got}")

    # claimed inversion: Lbox -> (Acent, Bcent, Shared, A_only, B_only)
    claimed_inv = {
        5: (8, 8, 8, 0, 0),
        7: (27, 27, 27, 0, 0),
        9: (64, 64, 64, 0, 0),
    }
    for L, claim in claimed_inv.items():
        got = r2[L][:5]
        match = (got == claim)
        ok = ok and match
        flag = "OK " if match else "*** MISMATCH ***"
        print(f"  inv L={L:<2} {flag}  verified {r2[L][5]}/{r2[L][6]}")
        if not match:
            print(f"      claimed: {claim}")
            print(f"      got    : {got}")

    print("\nRESULT:", "ALL CLAIMS REPRODUCED" if ok else "DISCREPANCIES FOUND")
