#!/usr/bin/env python3
"""
TMS Paper 5, Appendix E, Stage 6
Level-1 vs Level-2 Structural Identity.

Hypothesis (App. E.3): the bifurcation pattern repeats at level 2 with
IDENTICAL structural numbers. Level-2 sites (all-even-coord integers,
storage frame) split by sum mod 4 in {0, 2} into two interpenetrating
FCC sublattices:
      A': sum == 0 (mod 4)
      B': sum == 2 (mod 4)
each independently supporting tetrahedral closure with the same n^3 tet
count and the same k = 3n null-space scaling as level 1.

Reuses the Stage 5 machinery (imported), changing only the site
generator and the sum-mod-4 residues.
"""

import numpy as np
from lp1_stage5 import (sublattice, find_tetrahedra, f2_nullspace_dim,
                        max_coordination, centroid, is_inversion_partner,
                        level1_sites)


def level2_sites(L_box):
    """All-even-coord integer sites in [0, L_box]^3."""
    rng = range(0, L_box + 1)
    return [(i, j, k) for i in rng for j in rng for k in rng
            if i % 2 == 0 and j % 2 == 0 and k % 2 == 0]


def structural_numbers(sites_func, resA, resB, L):
    s = sites_func(L)
    A = sublattice(s, resA)
    B = sublattice(s, resB)
    tA = find_tetrahedra(A)
    tB = find_tetrahedra(B)
    kA = f2_nullspace_dim(A, tA)
    kB = f2_nullspace_dim(B, tB)
    return {
        "A": A, "B": B, "tA": tA, "tB": tB,
        "A_sites": len(A), "B_sites": len(B),
        "A_tets": len(tA), "B_tets": len(tB),
        "A_k": kA, "B_k": kB,
        "A_maxNN": max_coordination(A), "B_maxNN": max_coordination(B),
    }


def stage6_identity_table():
    """Compare level-1 and level-2 at matched level-local depth n.
    Level 1: L1 = 2n+1 (all-odd in [1, L1]).
    Level 2: L2 = 2n+2 (all-even in [0, L2]) gives even coords 0,2,...,2n
             -> (n+1) values per axis, same count structure as level 1's
             n+1 odd values 1,3,...,2n+1."""
    print("STAGE 6 -- Level-1 vs Level-2 structural identity")
    print(f"{'n':>2} | {'L1:tets':>7} {'L2:tets':>7} {'match':>5} "
          f"| {'L1:k':>4} {'L2:k':>4} {'match':>5}")
    rows = {}
    for n in (2, 3, 4, 5):
        L1 = 2*n + 1          # all-odd box for level 1
        L2 = 2*n              # all-even coords 0..2n -> n+1 per axis
        s1 = structural_numbers(level1_sites, 1, 3, L1)
        s2 = structural_numbers(level2_sites, 0, 2, L2)
        # combine both sublattices' tets (per-sublattice tet count is equal;
        # report the per-sublattice value matching App. E.3 which lists a
        # single tets column = per-sublattice n^3)
        l1_tets = s1["A_tets"]
        l2_tets = s2["A_tets"]
        l1_k = s1["A_k"]
        l2_k = s2["A_k"]
        m_tets = (l1_tets == l2_tets)
        m_k = (l1_k == l2_k)
        rows[n] = (l1_tets, l2_tets, m_tets, l1_k, l2_k, m_k)
        print(f"{n:>2} | {l1_tets:>7} {l2_tets:>7} {'Y' if m_tets else 'N':>5} "
              f"| {l1_k:>4} {l2_k:>4} {'Y' if m_k else 'N':>5}")
    return rows


def stage6_inversion_table():
    print("\nSTAGE 6 -- Inversion-partnership at level 2")
    print(f"{'Lbox':>4} | {'Acent':>6} {'Bcent':>6} {'Shared':>6} "
          f"| {'invVerified':>12}")
    rows = {}
    for L in (6, 8, 10, 12):
        s = structural_numbers(level2_sites, 0, 2, L)
        A, B = s["A"], s["B"]
        tA, tB = s["tA"], s["tB"]
        cA = {centroid(A, t): t for t in tA}
        cB = {centroid(B, t): t for t in tB}
        shared = set(cA) & set(cB)
        sample = list(shared)[:5]
        verified = sum(1 for c in sample
                       if is_inversion_partner(A, cA[c], B, cB[c]))
        rows[L] = (len(cA), len(cB), len(shared), verified, len(sample))
        print(f"{L:>4} | {len(cA):>6} {len(cB):>6} {len(shared):>6} "
              f"| {verified:>5}/{len(sample):<6}")
    return rows


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    r1 = stage6_identity_table()
    r2 = stage6_inversion_table()

    print("\n" + "="*60)
    print("CHECK vs Appendix E.3 claimed numbers")
    print("="*60)

    # claimed identity: n -> (L1_tets, L2_tets, L1_k, L2_k), all matching
    claimed_id = {
        2: (8, 8, 6, 6),
        3: (27, 27, 9, 9),
        4: (64, 64, 12, 12),
        5: (125, 125, 15, 15),
    }
    ok = True
    for n, (t1, t2, k1, k2) in claimed_id.items():
        got = r1[n]
        match = (got[0] == t1 and got[1] == t2 and got[3] == k1 and got[4] == k2
                 and got[2] and got[5])
        ok = ok and match
        print(f"  n={n}  {'OK ' if match else '*** MISMATCH ***'}")
        if not match:
            print(f"      claimed tets {t1}/{t2}, k {k1}/{k2}")
            print(f"      got {got}")

    # claimed inversion at level 2: Lbox -> shared count
    claimed_inv = {6: 27, 8: 64, 10: 125, 12: 216}
    for L, sh in claimed_inv.items():
        got = r2[L]
        match = (got[2] == sh and got[0] == sh and got[1] == sh)
        ok = ok and match
        print(f"  inv L={L:<2} {'OK ' if match else '*** MISMATCH ***'}  "
              f"shared={got[2]} (claimed {sh}), verified {got[3]}/{got[4]}")

    print("\nRESULT:", "ALL CLAIMS REPRODUCED" if ok else "DISCREPANCIES FOUND")
