#!/usr/bin/env python3
"""
TMS Paper 5, Appendix E, Stage 7
Classical [[4,2,2]] Stabilizer Dynamics (syndrome / error-detection).

The corpus (Paper 1, S5.1) specifies the canonical [[4,2,2]] code:
    S_X = X1 X2 X3 X4
    S_Z = Z1 Z2 Z3 Z4
4 physical qubits, 2 logical qubits, code distance 2.

This stage simulates the *classical* stabilizer dynamics that the corpus
actually leans on (S5.1-5.3): represent errors as Pauli strings, compute
syndromes via commutation with the two stabilizers, and confirm the
distance-2 property -- EVERY single-qubit Pauli error produces a nonzero
syndrome (is detectable), and the only undetectable nontrivial errors are
weight >= 2 logical operators.

Pauli bookkeeping is done in the symplectic (binary) representation:
each single-qubit Pauli on n=4 qubits is a 2n-bit vector (x | z).
Stabilizer S_X = XXXX has x=(1111), z=(0000).
Stabilizer S_Z = ZZZZ has x=(0000), z=(1111).
Two Paulis P=(xP|zP), Q=(xQ|zQ) COMMUTE iff the symplectic product
    <P,Q> = xP.zQ + zP.xQ  (mod 2)  == 0.
A stabilizer S flags error E (syndrome bit = 1) iff E ANTICOMMUTES with S.
"""

import itertools
import numpy as np

N = 4  # physical qubits

# stabilizers in symplectic form (x-part, z-part), each length N
S_X = (np.array([1, 1, 1, 1]), np.array([0, 0, 0, 0]))  # XXXX
S_Z = (np.array([0, 0, 0, 0]), np.array([1, 1, 1, 1]))  # ZZZZ
STABS = {"S_X": S_X, "S_Z": S_Z}


def symplectic_product(P, Q):
    """<P,Q> mod 2; 0 => commute, 1 => anticommute."""
    xP, zP = P
    xQ, zQ = Q
    return int((xP @ zQ + zP @ xQ) % 2)


def syndrome(E):
    """Syndrome of error E against the two stabilizers.
    Returns (s_X, s_Z): 1 if E anticommutes with that stabilizer."""
    return (symplectic_product(E, S_X), symplectic_product(E, S_Z))


def pauli_from_string(s):
    """'IXYZ' -> symplectic (x|z). X:x=1,z=0  Z:x=0,z=1  Y:x=1,z=1  I:0,0."""
    x = np.zeros(N, dtype=int)
    z = np.zeros(N, dtype=int)
    for i, ch in enumerate(s):
        if ch in "XY":
            x[i] = 1
        if ch in "ZY":
            z[i] = 1
    return (x, z)


def weight(s):
    return sum(1 for ch in s if ch != "I")


# ----------------------------------------------------------------------
# Test 1: every single-qubit Pauli error is detectable (distance >= 2)
# ----------------------------------------------------------------------
def test_single_qubit_detectable():
    print("STAGE 7a -- single-qubit error detectability")
    print(f"{'error':>6} {'S_X':>4} {'S_Z':>4}  {'detected':>8}")
    all_detected = True
    for pos in range(N):
        for p in "XYZ":
            s = "I"*pos + p + "I"*(N-pos-1)
            sX, sZ = syndrome(pauli_from_string(s))
            det = (sX, sZ) != (0, 0)
            all_detected = all_detected and det
            print(f"{s:>6} {sX:>4} {sZ:>4}  {'YES' if det else 'NO':>8}")
    print(f"  => all single-qubit errors detected: {all_detected}")
    return all_detected


# ----------------------------------------------------------------------
# Test 2: syndrome-flavor mapping matches corpus S5.1
#   X-type single error  -> flags S_Z  (S_Z = -1)
#   Z-type single error  -> flags S_X  (S_X = -1)
# ----------------------------------------------------------------------
def test_syndrome_flavor():
    print("\nSTAGE 7b -- syndrome-flavor mapping (corpus S5.1)")
    ok = True
    for pos in range(N):
        # X-type error should flag S_Z only
        eX = pauli_from_string("I"*pos + "X" + "I"*(N-pos-1))
        sX, sZ = syndrome(eX)
        x_ok = (sX == 0 and sZ == 1)
        # Z-type error should flag S_X only
        eZ = pauli_from_string("I"*pos + "Z" + "I"*(N-pos-1))
        sX2, sZ2 = syndrome(eZ)
        z_ok = (sX2 == 1 and sZ2 == 0)
        ok = ok and x_ok and z_ok
    print(f"  X-type single errors flag S_Z only: {x_ok}")
    print(f"  Z-type single errors flag S_X only: {z_ok}")
    print("  (matches corpus: bit-flip->S_Z=-1, phase->S_X=-1)")
    return ok


# ----------------------------------------------------------------------
# Test 3: exhaustive code distance.
# Distance = min weight of an undetectable nontrivial Pauli (a logical op).
# Enumerate all 4^4 = 256 Paulis; an undetectable error has syndrome (0,0)
# AND is not in the stabilizer group (i.e. acts nontrivially on code space).
# The minimum weight of such a "logical" operator is the code distance.
# ----------------------------------------------------------------------
def stabilizer_group_strings():
    """The 4 elements of the stabilizer group <XXXX, ZZZZ> as symplectic."""
    grp = []
    for a, b in itertools.product([0, 1], repeat=2):
        x = (a*S_X[0] + b*S_Z[0]) % 2
        z = (a*S_X[1] + b*S_Z[1]) % 2
        grp.append((tuple(x), tuple(z)))
    return set(grp)


def test_code_distance():
    print("\nSTAGE 7c -- exhaustive code distance (all 256 Paulis)")
    grp = stabilizer_group_strings()
    undetectable_logical = []
    for combo in itertools.product("IXYZ", repeat=N):
        s = "".join(combo)
        E = pauli_from_string(s)
        if syndrome(E) == (0, 0):
            key = (tuple(E[0]), tuple(E[1]))
            if key not in grp and weight(s) > 0:
                undetectable_logical.append((weight(s), s))
    undetectable_logical.sort()
    distance = undetectable_logical[0][0] if undetectable_logical else None
    print(f"  smallest undetectable nontrivial (logical) operators:")
    minw = undetectable_logical[0][0]
    for w, s in undetectable_logical:
        if w == minw:
            print(f"      weight {w}: {s}")
    print(f"  => CODE DISTANCE = {distance}")
    return distance


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    t1 = test_single_qubit_detectable()
    t2 = test_syndrome_flavor()
    d = test_code_distance()

    print("\n" + "="*60)
    print("CHECK vs corpus claims (Paper 1 S5.1-5.3)")
    print("="*60)
    print(f"  all single-qubit errors detectable : {t1}  (claim: yes)")
    print(f"  syndrome-flavor mapping correct     : {t2}  (claim: yes)")
    print(f"  code distance                       : {d}    (claim: 2)")
    ok = t1 and t2 and (d == 2)
    print("\nRESULT:", "ALL [[4,2,2]] CLASSICAL CLAIMS REPRODUCED"
          if ok else "DISCREPANCY FOUND")
