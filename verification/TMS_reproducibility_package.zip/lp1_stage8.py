#!/usr/bin/env python3
"""
TMS Paper 5, Appendix E, Stage 8
Full Quantum [[4,2,2]] Simulation on State Vectors.

Goes beyond the classical syndrome calculus of Stage 7: build the actual
2^4 = 16-dimensional Hilbert space, construct the [[4,2,2]] code space as
the simultaneous (+1,+1) eigenspace of S_X = XXXX and S_Z = ZZZZ, prepare
an arbitrary logical state, apply every single-qubit Pauli error, and
measure the stabilizers by projection. Confirms:

  1. The code space is exactly 4-dimensional (2 logical qubits).
  2. A clean logical state sits in the (+1,+1) syndrome sector.
  3. Every single-qubit Pauli error moves the state into a NONTRIVIAL
     syndrome sector (is detected), with the syndrome flavor matching
     the corpus mapping.
  4. The logical information is recoverable after detection (the error
     maps code space to an orthogonal error space, preserving the logical
     content for correction) -- distance-2 error DETECTION.

Standard qubit conventions, qubit 0 is the leftmost / most-significant.
"""

import numpy as np
import itertools

# single-qubit operators
I2 = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
PAULI = {"I": I2, "X": X, "Y": Y, "Z": Z}

N = 4
DIM = 2**N


def kron_string(s):
    """Tensor product of single-qubit Paulis given by a 4-char string."""
    M = np.array([[1]], dtype=complex)
    for ch in s:
        M = np.kron(M, PAULI[ch])
    return M


SX = kron_string("XXXX")
SZ = kron_string("ZZZZ")


def projector(stab, eigval):
    """Projector onto the eigval (+1/-1) eigenspace of a stabilizer."""
    return (np.eye(DIM, dtype=complex) + eigval * stab) / 2


def code_space_basis():
    """Orthonormal basis for the (+1,+1) simultaneous eigenspace."""
    P = projector(SX, +1) @ projector(SZ, +1)
    # eigen-decompose the projector; eigenvectors with eigenvalue ~1 span code space
    vals, vecs = np.linalg.eigh(P)
    basis = [vecs[:, i] for i in range(DIM) if abs(vals[i] - 1) < 1e-9]
    return basis


def syndrome_of_state(psi):
    """Measure both stabilizers on psi (assumed a stabilizer eigenstate).
    Returns (eig_SX, eig_SZ) in {+1,-1}, and a 'mixed' flag if psi is not
    a clean eigenstate of a stabilizer."""
    out = []
    for stab in (SX, SZ):
        exp = np.real(np.vdot(psi, stab @ psi))
        # for a clean eigenstate exp is +-1
        eig = +1 if exp > 0.5 else (-1 if exp < -0.5 else 0)
        out.append(eig)
    return tuple(out)


def normalize(v):
    return v / np.linalg.norm(v)


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25", precision=4, suppress=True)

    # --- 1. code space dimension ---
    basis = code_space_basis()
    print("STAGE 8a -- code space dimension")
    print(f"  dim(code space) = {len(basis)}   (claim: 4 = 2 logical qubits)")
    dim_ok = (len(basis) == 4)

    # --- 2. a clean logical state has syndrome (+1,+1) ---
    # build a random normalized state inside the code space
    rng = np.random.default_rng(42)
    coeffs = rng.normal(size=len(basis)) + 1j*rng.normal(size=len(basis))
    psi_L = normalize(sum(c*b for c, b in zip(coeffs, basis)))
    s_clean = syndrome_of_state(psi_L)
    print("\nSTAGE 8b -- clean logical state syndrome")
    print(f"  syndrome(clean) = {s_clean}   (claim: (+1,+1))")
    clean_ok = (s_clean == (1, 1))

    # --- 3. every single-qubit Pauli error is detected ---
    print("\nSTAGE 8c -- single-qubit error detection (projective syndrome)")
    print(f"  {'error':>6} {'S_X':>4} {'S_Z':>4}  {'detected':>8}  {'flavor':>14}")
    all_detected = True
    flavor_ok = True
    for pos in range(N):
        for p in "XYZ":
            s = "I"*pos + p + "I"*(N-pos-1)
            E = kron_string(s)
            psi_err = E @ psi_L
            sx, sz = syndrome_of_state(psi_err)
            detected = (sx, sz) != (1, 1)
            all_detected = all_detected and detected
            # corpus flavor: X-type flips S_Z (->-1); Z-type flips S_X (->-1)
            if p == "X":
                flavor = "S_Z flips" if sz == -1 and sx == +1 else "?"
                flavor_ok = flavor_ok and (sz == -1 and sx == +1)
            elif p == "Z":
                flavor = "S_X flips" if sx == -1 and sz == +1 else "?"
                flavor_ok = flavor_ok and (sx == -1 and sz == +1)
            else:  # Y = both
                flavor = "both flip" if sx == -1 and sz == -1 else "?"
                flavor_ok = flavor_ok and (sx == -1 and sz == -1)
            print(f"  {s:>6} {sx:>4} {sz:>4}  {'YES' if detected else 'NO':>8}"
                  f"  {flavor:>14}")
    print(f"  => all single-qubit errors detected: {all_detected}")

    # --- 4. logical content preserved: error space orthogonal to code space ---
    # For genuine error DETECTION, E|psi_L> must be orthogonal to the code
    # space whenever E is a detectable error (so no logical info is lost,
    # only displaced into a distinct syndrome sector).
    print("\nSTAGE 8d -- logical information preserved under detected errors")
    P_code = projector(SX, +1) @ projector(SZ, +1)
    max_leak = 0.0
    for pos in range(N):
        for p in "XYZ":
            s = "I"*pos + p + "I"*(N-pos-1)
            E = kron_string(s)
            psi_err = E @ psi_L
            leak = np.real(np.vdot(psi_err, P_code @ psi_err))  # overlap with code space
            max_leak = max(max_leak, leak)
    print(f"  max overlap of any errored state with code space = {max_leak:.2e}")
    print("  (≈0 => every detected error lands fully outside the code space,")
    print("   so the logical state is recoverable, not corrupted)")
    preserved_ok = (max_leak < 1e-9)

    print("\n" + "="*60)
    print("CHECK vs corpus claims (Paper 1 S5.1-5.3)")
    print("="*60)
    print(f"  code space dimension == 4           : {dim_ok}")
    print(f"  clean logical syndrome == (+1,+1)   : {clean_ok}")
    print(f"  all single-qubit errors detected    : {all_detected}")
    print(f"  syndrome flavors match corpus map   : {flavor_ok}")
    print(f"  logical info preserved (distance 2) : {preserved_ok}")
    ok = dim_ok and clean_ok and all_detected and flavor_ok and preserved_ok
    print("\nRESULT:", "FULL QUANTUM [[4,2,2]] CONFIRMS CORPUS"
          if ok else "DISCREPANCY FOUND")
