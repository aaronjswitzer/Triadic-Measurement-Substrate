#!/usr/bin/env python3
"""
TMS Paper 5, Appendix E, Stage 9
Program-Zoo Enumeration and the Minimum Program Scale L_p.

WHAT THE CORPUS ACTUALLY CLAIMS (Paper 3 S6.2 Program definition; Paper 5
S4.1 minimum program scale):

  A "program" is a polarization configuration C selected by LOCAL GEOMETRIC
  rules -- T-closure (reproduces under the flop operator T, possibly up to
  lattice translation) plus stabilizer parity -- NOT by computing K(C).
  The corpus is explicit (S6.2 remark): the substrate does not compute
  Kolmogorov complexity; K(C) < |C| is an EMERGENT PROPERTY of the
  survivors, the external observer's description of what the geometric
  criteria pick out.

  The minimum program scale L_p (Paper 5 S4.1) is the smallest region that
  can host a non-trivial program: claimed L_p ~ (4-8) ell_p, and strictly
  L_p > ell_p (a single confirmed bit is NOT a program because K(C) ~ |C|).

WHAT THIS STAGE DOES (honestly):
  1. Model the polarization landscape as a binary field on a small FCC
     patch (the corpus's "signed polarization" chi in {+,-} per site).
  2. Define a concrete local flop operator T as a deterministic
     majority-rule update on the FCC neighbourhood -- this is the corpus's
     own "three-input majority gate" / "deterministic majority behavior at
     scale" (Paper 0 abstract; Paper 2). This is a MODELING CHOICE made to
     instantiate T concretely; flagged as such.
  3. Enumerate all configurations on small patches, find the T-closed ones
     (T^n[C] = C up to translation) that also satisfy stabilizer parity.
  4. Measure compressibility of survivors vs random configs with a
     concrete K-proxy (zlib compressed length), to TEST the corpus's
     central claim that geometric selection => K(C) < |C|.
  5. Determine the smallest patch that hosts a non-trivial (non-uniform)
     program -> empirical L_p, compared against the claimed (4-8) ell_p.

K-PROXY CAVEAT: true Kolmogorov complexity is uncomputable (the corpus
says so). We use compressed-length as a standard upper-bound proxy. A
config "looks compressible" if its compressed length is clearly below
that of random configs of the same size. This is evidence, not proof.
"""

import itertools
import zlib
import numpy as np


# ----------------------------------------------------------------------
# FCC patch: sites with i+j+k even in a small cube (the agent lattice,
# Paper 1). Polarization chi in {0,1} (representing -/+).
# ----------------------------------------------------------------------
def fcc_patch(L):
    return [(i, j, k)
            for i in range(L) for j in range(L) for k in range(L)
            if (i + j + k) % 2 == 0]


def fcc_neighbors(site, site_set):
    """12 FCC nearest neighbours at squared distance 2 (face diagonals)."""
    i, j, k = site
    nbrs = []
    for di, dj, dk in itertools.product((-1, 0, 1), repeat=3):
        if di*di + dj*dj + dk*dk == 2:
            n = (i+di, j+dj, k+dk)
            if n in site_set:
                nbrs.append(n)
    return nbrs


# ----------------------------------------------------------------------
# Flop operator T: deterministic majority rule on FCC neighbourhood.
# (Corpus: confirmation = three-input majority gate; stabilizer dynamics
#  push effective logic to deterministic majority at scale.)
# T[chi](site) = majority of neighbour values; tie -> keep own value.
# ----------------------------------------------------------------------
def apply_T(chi, sites, site_set, nbr_map):
    new = {}
    for s in sites:
        vals = [chi[n] for n in nbr_map[s]]
        if not vals:
            new[s] = chi[s]
            continue
        ones = sum(vals)
        zeros = len(vals) - ones
        if ones > zeros:
            new[s] = 1
        elif zeros > ones:
            new[s] = 0
        else:
            new[s] = chi[s]  # tie -> hold
    return new


def config_to_tuple(chi, sites):
    return tuple(chi[s] for s in sites)


def is_T_closed(chi, sites, site_set, nbr_map, max_period=4):
    """True if T^n[chi] == chi (exactly, same patch) for some n<=max_period.
    Returns the period, or None. (Translation-invariance on a tiny bounded
    patch is not well-defined, so we use exact fixed/periodic closure --
    the stricter, more honest test on a finite patch.)"""
    seen = {config_to_tuple(chi, sites): 0}
    cur = dict(chi)
    for step in range(1, max_period + 1):
        cur = apply_T(cur, sites, site_set, nbr_map)
        t = config_to_tuple(cur, sites)
        if t == config_to_tuple(chi, sites):
            return step
        if t in seen:
            return None  # fell into a different cycle, not closed on C
        seen[t] = step
    return None


# ----------------------------------------------------------------------
# Stabilizer parity: each FCC tetrahedron (4 mutual NN at sq-dist 2) must
# have even parity sum (the classical shadow of S_Z = ZZZZ = +1).
# ----------------------------------------------------------------------
def find_fcc_tetrahedra(sites, site_set):
    n = len(sites)
    idx = {s: i for i, s in enumerate(sites)}
    adj = {s: set(fcc_neighbors(s, site_set)) for s in sites}
    tets = []
    sl = sorted(sites)
    for a in sl:
        for b in adj[a]:
            if b <= a:
                continue
            for c in adj[a] & adj[b]:
                if c <= b:
                    continue
                for d in adj[a] & adj[b] & adj[c]:
                    if d <= c:
                        continue
                    tets.append((a, b, c, d))
    return tets


def satisfies_stabilizer_parity(chi, tets):
    """All tetrahedra have even parity (classical S_Z = +1 shadow)."""
    for tet in tets:
        if sum(chi[s] for s in tet) % 2 != 0:
            return False
    return True


# ----------------------------------------------------------------------
# Compressibility proxy
# ----------------------------------------------------------------------
def k_proxy(bits):
    """zlib-compressed length in bytes of the bitstring (upper bound on K)."""
    b = bytes(bits)
    return len(zlib.compress(b, level=9))


def is_nontrivial(bits):
    """Non-uniform: contains at least one boundary (both 0s and 1s).
    A uniform config is the trivial program; the corpus requires a
    non-trivial program to have at least one domain boundary (S4.1)."""
    return 0 < sum(bits) < len(bits)


# ----------------------------------------------------------------------
# Driver: enumerate programs on patches of increasing size
# ----------------------------------------------------------------------
def enumerate_patch(L, max_sites_for_exhaustive=16):
    sites = fcc_patch(L)
    site_set = set(sites)
    nbr_map = {s: fcc_neighbors(s, site_set) for s in sites}
    tets = find_fcc_tetrahedra(sites, site_set)
    n = len(sites)

    result = {
        "L": L, "n_sites": n, "n_tets": len(tets),
        "exhaustive": n <= max_sites_for_exhaustive,
        "programs": [], "nontrivial_programs": [],
    }

    if n == 0:
        return result

    if n <= max_sites_for_exhaustive:
        configs = itertools.product((0, 1), repeat=n)
    else:
        # sample if too big for full enumeration
        rng = np.random.default_rng(0)
        configs = (tuple(rng.integers(0, 2, n)) for _ in range(200000))

    for cfg in configs:
        chi = {s: cfg[i] for i, s in enumerate(sites)}
        if tets and not satisfies_stabilizer_parity(chi, tets):
            continue
        period = is_T_closed(chi, sites, site_set, nbr_map)
        if period is None:
            continue
        bits = list(cfg)
        entry = (period, tuple(bits))
        result["programs"].append(entry)
        if is_nontrivial(bits):
            result["nontrivial_programs"].append(entry)

    return result


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("STAGE 9 -- Program-zoo enumeration on FCC patches")
    print("(T = deterministic FCC-majority flop; stabilizer = even tet parity)\n")
    print(f"{'L':>2} {'sites':>5} {'tets':>4} {'exh':>4} "
          f"{'#prog':>6} {'#nontrivial':>11} {'min|C| nontriv':>14}")

    summary = {}
    first_nontrivial_L = None
    for L in range(2, 7):
        r = enumerate_patch(L)
        nontriv = r["nontrivial_programs"]
        min_extent = min((sum(1 for _ in p[1]) for p in nontriv), default=None)
        # spatial extent: number of sites in the patch hosting it
        summary[L] = r
        print(f"{L:>2} {r['n_sites']:>5} {r['n_tets']:>4} "
              f"{'Y' if r['exhaustive'] else 'N':>4} "
              f"{len(r['programs']):>6} {len(nontriv):>11} "
              f"{r['n_sites'] if nontriv else '-':>14}")
        if nontriv and first_nontrivial_L is None:
            first_nontrivial_L = L

    # ---- compressibility test: survivors vs random ----
    print("\n" + "="*60)
    print("COMPRESSIBILITY: do geometrically-selected programs satisfy")
    print("K(C) < |C|, vs random configs with K ~ |C|?  (zlib proxy)")
    print("="*60)
    # use the largest exhaustive patch with nontrivial programs
    test_L = None
    for L in sorted(summary, reverse=True):
        if summary[L]["exhaustive"] and summary[L]["nontrivial_programs"]:
            test_L = L
            break
    if test_L is not None:
        r = summary[test_L]
        n = r["n_sites"]
        prog_bits = [list(p[1]) for p in r["nontrivial_programs"]]
        prog_k = [k_proxy(b) for b in prog_bits]
        rng = np.random.default_rng(1)
        rand_k = [k_proxy(list(rng.integers(0, 2, n))) for _ in range(2000)]
        raw_len = len(zlib.compress(bytes([0]*0)))  # baseline
        print(f"  patch L={test_L}, {n} sites, "
              f"{len(prog_bits)} nontrivial programs")
        print(f"  mean K-proxy (programs) : {np.mean(prog_k):.2f} bytes")
        print(f"  mean K-proxy (random)   : {np.mean(rand_k):.2f} bytes")
        print(f"  programs more compressible than random: "
              f"{np.mean(prog_k) < np.mean(rand_k)}")
    else:
        print("  (no exhaustive patch with nontrivial programs in range)")

    # ---- L_p verdict ----
    print("\n" + "="*60)
    print("MINIMUM PROGRAM SCALE L_p")
    print("="*60)
    print(f"  smallest patch hosting a non-trivial program: L = "
          f"{first_nontrivial_L}")
    if first_nontrivial_L is not None:
        n_at = summary[first_nontrivial_L]["n_sites"]
        print(f"    -> spans {n_at} FCC sites; linear extent ~{first_nontrivial_L}"
              f" lattice spacings")
    print(f"  corpus claim: L_p ~ (4-8) ell_p, strictly L_p > ell_p")
    print(f"  single-bit-is-not-a-program check: ", end="")
    # a single nonzero bit on the smallest patch
    one_site = enumerate_patch(2)
    singles = [p for p in one_site["programs"]
               if sum(p[1]) == 1]
    print(f"{'CONFIRMED (no single-bit nontrivial program)' if not singles else 'single-bit program exists!'}")
