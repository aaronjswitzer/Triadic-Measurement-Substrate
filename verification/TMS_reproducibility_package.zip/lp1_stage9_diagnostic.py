#!/usr/bin/env python3
"""
Diagnostic for Stage 9: why do T-closed programs vanish at L>=4?
Hypothesis: bounded-patch boundary effects. The majority flop on a finite
patch drives interior toward uniformity but boundary sites see truncated
neighbourhoods, breaking exact closure. The corpus allows closure "up to
lattice translation" and implicitly on an extended/periodic medium.

Test A: re-run closure on a PERIODIC patch (torus) so every site has a
full 12-neighbour FCC shell -- removes boundary truncation.
Test B: report, for L=4, how many configs reach a fixed point of T at all
(regardless of equalling the START config) -- i.e. count T-attractors.
"""
import itertools
import numpy as np


def fcc_patch(L):
    return [(i, j, k)
            for i in range(L) for j in range(L) for k in range(L)
            if (i + j + k) % 2 == 0]


def fcc_neighbors_periodic(site, L):
    """12 FCC NN on a periodic L^3 torus (wrap coords)."""
    i, j, k = site
    nbrs = []
    for di, dj, dk in itertools.product((-1, 0, 1), repeat=3):
        if di*di + dj*dj + dk*dk == 2:
            n = ((i+di) % L, (j+dj) % L, (k+dk) % L)
            if (n[0]+n[1]+n[2]) % 2 == 0:
                nbrs.append(n)
    return nbrs


def apply_T(chi, sites, nbr_map):
    new = {}
    for s in sites:
        vals = [chi[n] for n in nbr_map[s]]
        ones = sum(vals); zeros = len(vals) - ones
        new[s] = 1 if ones > zeros else (0 if zeros > ones else chi[s])
    return new


def tup(chi, sites):
    return tuple(chi[s] for s in sites)


def closure_period(cfg, sites, nbr_map, max_period=6):
    chi = {s: cfg[i] for i, s in enumerate(sites)}
    start = tup(chi, sites)
    cur = dict(chi)
    for step in range(1, max_period+1):
        cur = apply_T(cur, sites, nbr_map)
        if tup(cur, sites) == start:
            return step
    return None


def reaches_fixed_point(cfg, sites, nbr_map, max_iter=20):
    chi = {s: cfg[i] for i, s in enumerate(sites)}
    prev = tup(chi, sites)
    for _ in range(max_iter):
        chi = apply_T(chi, sites, nbr_map)
        cur = tup(chi, sites)
        if cur == prev:
            return cur  # fixed point reached
        prev = cur
    return None


if __name__ == "__main__":
    np.set_printoptions(legacy="1.25")
    print("DIAGNOSTIC -- periodic (torus) closure vs bounded")
    print(f"{'L':>2} {'sites':>5} {'periodic #closed':>16} "
          f"{'#nontrivial':>11} {'#distinct fixed pts':>19}")

    for L in (2, 4, 6):
        sites = fcc_patch(L)
        n = len(sites)
        nbr_map = {s: fcc_neighbors_periodic(s, L) for s in sites}

        if n > 18:
            # sample
            rng = np.random.default_rng(0)
            configs = [tuple(rng.integers(0, 2, n)) for _ in range(100000)]
            exhaustive = False
        else:
            configs = list(itertools.product((0, 1), repeat=n))
            exhaustive = True

        closed = 0
        nontrivial = 0
        fixed_pts = set()
        for cfg in configs:
            p = closure_period(cfg, sites, nbr_map)
            if p is not None:
                closed += 1
                if 0 < sum(cfg) < n:
                    nontrivial += 1
            fp = reaches_fixed_point(cfg, sites, nbr_map)
            if fp is not None:
                fixed_pts.add(fp)

        tag = "" if exhaustive else " (sampled)"
        print(f"{L:>2} {n:>5} {closed:>16} {nontrivial:>11} "
              f"{len(fixed_pts):>19}{tag}")

    print("\nInterpretation:")
    print("  If periodic closure restores nontrivial programs at L=4,6,")
    print("  the Stage-9 collapse was a bounded-patch boundary artifact,")
    print("  NOT a TMS property -- the corpus's 'up to lattice translation'")
    print("  closure needs an extended medium to be tested faithfully.")
