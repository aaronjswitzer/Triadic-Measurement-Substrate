#!/usr/bin/env python3
"""
Can the global chirality asymmetry be closed using R-hat's established
irreversibility? Or does it only LOOK closeable?

THE PROBLEM (Nielsen-Ninomiya, global form):
On any local, Hermitian, translation-invariant lattice in d dimensions, the net
chirality of fermion modes is ZERO -- left and right handed modes come in pairs
(fermion doubling). A domain wall gives a chiral mode on the wall, but on a CLOSED
space a wall and an anti-wall appear together, binding opposite-handed modes that
cancel. So net global chirality requires the extra dimension (here the hierarchy
direction, the R-hat axis) to be EFFECTIVELY ONE-SIDED / SEMI-INFINITE, not a
closed loop -- otherwise the two ends host opposite chiralities that cancel.

WHAT THE CORPUS ESTABLISHES about the R-hat axis:
- R-hat (reinterpretation) is IRREVERSIBLE: the daughter substrate cannot be
  overwritten by, nor reconstruct, the parent (Axiom 3, no-overwrite; the
  "frozen arrow"). Confirmed present in the text (lines 8532, 8587, 8612, 11164).
- Each reinterpretation freezes ONE arrow direction into the daughter geometry.
- The parent-to-child map is single-valued forward but NOT invertible backward
  (many parent microstates -> one daughter initial condition; information is lost
  across the R-hat boundary).

THE TEST: does irreversibility (no backward map) give the SAME thing as
one-sidedness (semi-infinite extra dimension) for the Nielsen-Ninomiya argument?

This is the crux and it must not be fudged. Let me reason it explicitly.
"""

print("="*70)
print("Does R-hat irreversibility close the global chirality gap?")
print("="*70)

print("""
STEP 1: What Nielsen-Ninomiya actually requires to evade doubling.
  The overlap/domain-wall construction gives a NET chiral mode iff the extra
  dimension is a HALF-LINE (boundary on one end only) or equivalently the two
  boundaries are INEQUIVALENT so their opposite-chirality modes do not cancel.
  A periodic (closed-loop) extra dimension -> net zero. A half-line or a pair of
  INEQUIVALENT ends -> net nonzero.

STEP 2: What R-hat's irreversibility gives.
  Irreversibility means the parent->daughter map has no inverse: you cannot run
  R-hat backward. In the hierarchy (extra) dimension, this means the two
  'directions' along the R-hat axis are PHYSICALLY INEQUIVALENT:
    - forward (parent -> daughter): allowed, single-valued, information-losing
    - backward (daughter -> parent): FORBIDDEN (no-overwrite, Axiom 3)
  So the R-hat axis is NOT a symmetric line and NOT a periodic loop. It is a
  DIRECTED axis with inequivalent ends: the parent end is a source (no earlier
  boundary of the same type is reachable), the daughter end continues forward.

STEP 3: The identification -- and its honest gap.
  A directed, non-invertible axis with inequivalent ends is EXACTLY the condition
  that breaks the wall/anti-wall cancellation: the two ends of the R-hat axis are
  not related by any symmetry (one is a source under an irreversible map, the
  other is not), so the opposite-chirality modes they would host are NOT forced
  to be equal-and-opposite. The cancellation that Nielsen-Ninomiya reasserts
  globally REQUIRES the two ends to be equivalent (related by the lattice
  symmetry). Irreversibility BREAKS that equivalence.

  => Irreversibility is SUFFICIENT to defeat the global cancellation, IF one more
     thing holds: that the symmetry-breaking between the ends actually couples to
     the CHIRAL mode (i.e. the inequivalence is not orthogonal to the handedness).

STEP 4: Does the inequivalence couple to handedness? (the make-or-break)
  The frozen-arrow result (line 8612) says each reinterpretation freezes ONE
  arrow direction INTO THE DAUGHTER'S SPATIAL GEOMETRY. The handedness (chirality)
  is defined relative to that spatial geometry. So the arrow that the R-hat
  direction freezes is the SAME structure that orients the spatial handedness --
  they are not independent. The inequivalence of the R-hat ends is therefore
  ALIGNED with the spatial orientation that defines L vs R, not orthogonal to it.

  => The coupling holds: the R-hat directedness is the same datum as the spatial
     orientation, so breaking end-equivalence breaks L/R degeneracy.
""")

print("="*70)
print("VERDICT")
print("="*70)
print("""
The logic CLOSES to the level of a structural derivation, NOT yet a computed
lattice index. Precisely:

  ESTABLISHED (now, from inherited results):
    (a) R-hat is irreversible => the hierarchy axis has inequivalent ends
        (not periodic, not symmetric) -- this defeats the wall/anti-wall
        cancellation that forces net-zero chirality. [Axiom 3, frozen arrow]
    (b) The frozen arrow that directs the R-hat axis is the SAME structure that
        orients spatial handedness (line 8612) => the end-inequivalence couples
        to chirality rather than being orthogonal to it.
    Together: net global chirality is STRUCTURALLY PERMITTED and SIGN-SELECTED by
    the parent-to-child direction. The 'plausible but not demonstrated' gap in
    the text is now closed at the STRUCTURAL level: the one-sidedness is not an
    extra assumption, it is R-hat's irreversibility, and it couples to handedness
    via the frozen arrow.

  STILL OPEN (honest):
    The NUMERICAL net chiral count (the overlap-operator index on the explicit
    R-hat boundary lattice) is not computed. Structural permission + sign is
    established; the integer is not. This is a real remaining calculation, but it
    is a SMALLER and BETTER-POSED gap than 'the asymmetry must come from
    somewhere': the somewhere is identified (R-hat irreversibility), the coupling
    is identified (the frozen arrow), and only the index computation remains.

So: not fully closed, but MOVED -- from 'plausible, not demonstrated' to
'structurally derived up to an index computation.' That is a real, honest
advance, and it is the correct amount to claim.
""")
