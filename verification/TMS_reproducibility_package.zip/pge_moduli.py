#!/usr/bin/env python3
"""
Can PGE's condition (i) -- 'fewest independent structural commitments' -- be made
a WELL-DEFINED, COMPUTABLE quantity, or does it depend on how you count?

This is the load-bearing question. The corpus's formal statement says C* has "the
fewest independent structural commitments" and equivalently "no element can be
uniquely determined from K with a smaller set of unforced parameter choices."

The hostile objection: "structural commitments" and "parameter choices" are not
defined -- you can count them however you like to get the answer you want.

THE FORMALIZATION ATTEMPT: replace the informal 'commitment count' with a
RIGOROUS, STANDARD measure: the DIMENSION OF THE MODULI / the number of
CONTINUOUS PARAMETERS needed to specify the configuration up to the symmetry
that K permits. This is well-defined: it's the dimension of the space of
configurations satisfying K, modulo the automorphisms K allows. A configuration
with fewer free real parameters (lower-dimensional moduli) is more economical.

Test it on the actual selections and see if it (a) is computable, (b) gives the
answer the corpus claims, (c) is UNIQUE (no counting ambiguity).
"""
import numpy as np

print("="*70)
print("PGE CONDITION (i) AS MODULI DIMENSION -- is it well-defined & computable?")
print("="*70)

# --- Selection 1: the geometric primitive (sphere vs alternatives) ---
# K = {isotropy, geometric primitive supporting Axiom-1 measurement}
# Count: dimension of shape-orientation parameters NOT fixed by K.
# A shape's "specification cost" = # real parameters to pin it down up to
# translation (K doesn't fix position) = orientation params + shape params.
print("\nSELECTION 1: geometric primitive")
print("-"*70)
primitives = {
  # (orientation params, shape params beyond scale) -- scale is fixed by l_p
  "sphere":            (0, 0),   # no orientation (isotropic), no shape dof
  "cube":              (3, 0),   # 3 Euler angles orientation
  "ellipsoid":         (3, 2),   # 3 orientation + 2 axis-ratios
  "regular tetrahedron":(3, 0),  # 3 orientation
  "irregular polyhedron":(3, 3), # orientation + shape
}
for name,(o,s) in primitives.items():
    total=o+s
    iso = "ISOTROPIC" if o==0 else f"{o} orient. params -> anisotropic"
    print(f"  {name:22}: {total} free params ({iso})")
mincost = min(o+s for o,s in primitives.values())
winners = [n for n,(o,s) in primitives.items() if o+s==mincost]
print(f"  => minimum free-parameter count = {mincost}, achieved uniquely by: {winners}")
print(f"  MODULI DIMENSION is well-defined and picks the sphere UNIQUELY. No")
print(f"  counting ambiguity: 'free real parameters up to K-symmetry' is standard.")

# --- Selection 2: triadic minimum (2 vs 3 vs 4 agents for 2D closure) ---
# K = {enclose a bit, planar (2D minimum), agents are spheres in contact}
# The 'commitment' measure: does the configuration CLOSE (enclose a region) with
# the fewest agents? This is a DISCRETE count -- number of agents -- plus the
# closure constraint. Here condition (i) is just: fewest agents that satisfy the
# closure requirement in K.
print("\nSELECTION 2: triadic minimum (2D enclosure)")
print("-"*70)
# geometric fact: n mutually-contacting equal circles enclose a bounded region iff n>=3
for n in [2,3,4]:
    encloses = (n>=3)
    print(f"  {n} agents: encloses a bounded interstice? {encloses}"
          + ("  <- minimal enclosing" if n==3 else ""))
print("  => condition (i) here = fewest agents achieving closure = 3. This is a")
print("     COUNTING fact (integer-valued), fully unambiguous. 2 fails closure")
print("     (fails to be in C_K at all); 4 is in C_K but non-minimal.")

# --- The KEY TEST: is the measure ambiguous anywhere? ---
# The worry: 'independent structural commitments' could be gamed. Test whether the
# moduli-dimension reading ever DISAGREES with the corpus, or is ill-defined.
print("\n"+"="*70)
print("IS THE MEASURE EVER AMBIGUOUS? (the hostile core)")
print("="*70)
print("""
The moduli-dimension reading of condition (i) is:
   cost(C) = dim of the space of configurations satisfying K that are
             equivalent to C under K-allowed symmetry, i.e. the number of
             REAL PARAMETERS that must be chosen, beyond what K forces, to
             specify C.
This is well-defined whenever K is specifiable as a set of constraints on a
configuration space -- which it is in every selection, because the axioms give
K explicitly. The measure is:
   - CONTINUOUS-parameter selections (sphere): dim of orientation+shape moduli.
   - DISCRETE selections (agent count): the integer count with the closure
     constraint from K.
Both are standard, both are unambiguous GIVEN K. 

THE HONEST RESIDUE: the ambiguity is NOT in counting parameters -- that's clean.
The ambiguity, if any, is in SPECIFYING K: which constraints are 'imposed by the
axioms and prior structure'? If K is chosen post-hoc to yield the desired C*,
THAT is where judgment could enter. So the formalization must require: K is
FIXED BY THE AXioms ALONE, declared BEFORE the selection, not reverse-engineered.
""")
