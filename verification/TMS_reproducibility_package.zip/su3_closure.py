#!/usr/bin/env python3
"""
Does the corpus's construction actually close to su(3)? DeepSeek Objection 1.
The corpus claims: value transport = so(3) (3 real antisymmetric generators),
momentum carry = i * (real symmetric traceless) (5 generators), and these 8
"close under commutation to exactly su(3), no overshoot."

COMPUTE IT. Build the 8 generators explicitly, take all pairwise commutators,
and check: (a) do they close within the span of the 8? (b) is that span exactly
su(3) = anti-Hermitian traceless 3x3? (c) does adding a 'forbidden direction'
break closure (the claimed overshoot detection)?
"""
import numpy as np
np.set_printoptions(precision=3, suppress=True)

# 3x3 real antisymmetric (so(3)): 3 generators
A1=np.array([[0,-1,0],[1,0,0],[0,0,0]],dtype=complex)
A2=np.array([[0,0,-1],[0,0,0],[1,0,0]],dtype=complex)
A3=np.array([[0,0,0],[0,0,-1],[0,1,0]],dtype=complex)
so3=[A1,A2,A3]

# i * real symmetric traceless (5 generators)
S1=1j*np.array([[1,0,0],[0,-1,0],[0,0,0]],dtype=complex)     # diag traceless
S2=1j*np.array([[1,0,0],[0,1,0],[0,0,-2]],dtype=complex)/np.sqrt(3)  # diag traceless
S3=1j*np.array([[0,1,0],[1,0,0],[0,0,0]],dtype=complex)
S4=1j*np.array([[0,0,1],[0,0,0],[1,0,0]],dtype=complex)
S5=1j*np.array([[0,0,0],[0,0,1],[0,1,0]],dtype=complex)
sym=[S1,S2,S3,S4,S5]

gens=so3+sym  # 8 generators
print("STAGE: explicit su(3) closure test")
print("="*60)
print(f"Number of generators: {len(gens)} (3 antisymmetric + 5 i*symmetric)")

# check each is anti-Hermitian and traceless
def anti_herm(M): return np.allclose(M, -M.conj().T)
def traceless(M): return abs(np.trace(M))<1e-12
print(f"All anti-Hermitian: {all(anti_herm(g) for g in gens)}")
print(f"All traceless:      {all(traceless(g) for g in gens)}")

# build a basis for the space they span (flatten, check rank)
flat=np.array([g.flatten() for g in gens])
# also build full su(3) basis (all anti-herm traceless 3x3 = 8-dim) to compare span
# Gell-Mann * i are a basis of su(3)
def gellmann():
    l=[]
    l.append(np.array([[0,1,0],[1,0,0],[0,0,0]],dtype=complex))
    l.append(np.array([[0,-1j,0],[1j,0,0],[0,0,0]],dtype=complex))
    l.append(np.array([[1,0,0],[0,-1,0],[0,0,0]],dtype=complex))
    l.append(np.array([[0,0,1],[0,0,0],[1,0,0]],dtype=complex))
    l.append(np.array([[0,0,-1j],[0,0,0],[1j,0,0]],dtype=complex))
    l.append(np.array([[0,0,0],[0,0,1],[0,1,0]],dtype=complex))
    l.append(np.array([[0,0,0],[0,0,-1j],[0,1j,0]],dtype=complex))
    l.append(np.array([[1,0,0],[0,1,0],[0,0,-2]],dtype=complex)/np.sqrt(3))
    return [1j*x for x in l]  # i*Gell-Mann = anti-herm traceless
su3=gellmann()

def in_span(M, basis):
    B=np.array([b.flatten() for b in basis]).T
    coeffs,res,rank,sv=np.linalg.lstsq(B, M.flatten(), rcond=None)
    recon=(B@coeffs).reshape(3,3)
    return np.allclose(recon, M, atol=1e-9)

# (a) do all commutators stay in the span of the 8 generators?
closes=True; max_out=0
for i in range(8):
    for j in range(8):
        C=gens[i]@gens[j]-gens[j]@gens[i]
        if not in_span(C, gens):
            closes=False
print(f"\n(a) All [g_i, g_j] lie in span of the 8 generators: {closes}")

# (b) is the span exactly su(3)? (each generator in su(3) span AND rank 8)
span_rank=np.linalg.matrix_rank(flat)
all_in_su3=all(in_span(g, su3) for g in gens)
print(f"(b) span has dimension {span_rank} (su(3) is 8); all generators in su(3): {all_in_su3}")
print(f"    => span is exactly su(3): {span_rank==8 and all_in_su3}")

# (c) overshoot test: add a 'forbidden' direction (a symmetric REAL, not i*symmetric,
#     i.e. a Hermitian traceless generator -> would push toward sl(3,C)). Check closure breaks.
F=np.array([[1,0,0],[0,-1,0],[0,0,0]],dtype=complex)  # real symmetric, NOT times i -> Hermitian
gens9=gens+[F]
closes9=True
for i in range(9):
    for j in range(9):
        C=gens9[i]@gens9[j]-gens9[j]@gens9[i]
        if not in_span(C, gens9):
            closes9=False
# more telling: does the forbidden generator's commutators leave the 8-dim su(3)?
leaves=False
for g in gens:
    C=F@g-g@F
    if not in_span(C, gens):
        leaves=True
print(f"\n(c) Adding a Hermitian (forbidden) direction: its commutators leave su(3): {leaves}")
print(f"    (This is the claimed 'overshoot detection' -- forbidden dir breaks closure: {leaves})")

print("\n"+"="*60)
print("VERDICT")
if closes and span_rank==8 and all_in_su3:
    print("The 8 substrate-built generators DO close to exactly su(3).")
    print("=> DeepSeek Obj.1 is PRESENTATION: the closure is real but not shown")
    print("   in the text. Fix = add this explicit commutator computation as an")
    print("   appendix. The claim itself holds.")
else:
    print("The generators do NOT close cleanly to su(3).")
    print("=> DeepSeek Obj.1 is REAL: the strongest claim has a genuine gap.")

# ADDENDUM: the CORRECT no-overshoot argument
print("\n"+"="*60)
print("ADDENDUM: the correct 'no overshoot' argument")
print("="*60)
# anti-Hermitian traceless 3x3 matrices form a real vector space of dimension:
# 3x3 complex = 9 complex = 18 real params. Anti-Hermitian: M = -M^dag.
#   diagonal: purely imaginary -> 3 real; off-diag: 3 complex pairs -> 6 real; total 9.
# traceless removes 1 (the sum of imaginary diagonals) -> 8 real. EXACTLY su(3).
print("""
anti-Hermitian 3x3: diagonal purely imaginary (3 real) + 3 off-diagonal
  complex entries determined in pairs (6 real) = 9 real dimensions.
traceless removes 1 (imaginary parts of diagonal sum to 0) => 8 real dimensions.
The space of anti-Hermitian traceless 3x3 matrices IS 8-dimensional and IS su(3).

Since the 8 generators are anti-Hermitian and traceless BY CONSTRUCTION, and any
commutator [X,Y] of anti-Hermitian matrices is anti-Hermitian, and any commutator
is automatically traceless (tr[X,Y]=0 identically), the bracket of any two
generators is STILL anti-Hermitian and traceless -- hence still in the same
8-dimensional space. Closure is AUTOMATIC, and there is no larger space to
overshoot into. This is the clean argument: it does not need 'forbidden
directions breaking closure' -- it needs only that anti-Herm + traceless is
8-dim and closed under the bracket, which it provably is.
""")
# verify: commutator of any two anti-herm is anti-herm and traceless
import numpy as np
X=gens[2]; Y=gens[5]; C=X@Y-Y@X
print(f"  spot check: [A3,S2] anti-Hermitian: {np.allclose(C,-C.conj().T)}, "
      f"traceless: {abs(np.trace(C))<1e-12}")
print("  => closure is forced by construction. The su(3) result is rigorous.")
