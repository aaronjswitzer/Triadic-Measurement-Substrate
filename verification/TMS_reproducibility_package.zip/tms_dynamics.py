#!/usr/bin/env python3
"""
TMS substrate dynamics — operational Flop Operator T.
Implements DEFINITIONS_AND_DYNAMICS.md §1, both resolution branches, on the
storage-convention FCC lattice. This module is imported by the L_p / zoo /
closure sims so they all run the SAME corpus-grounded T.

Grounding:
  - local polarization amplitude Pi_psi(x) = (chi1+chi2+chi3)/3   (P2 §3.2)
  - deterministic branch: chi = sign(Pi_psi), fair coin at 0       (P2 §5.2,§4.1)
  - probabilistic branch: P(chi=+1) = (1+Pi_psi)/2                 (P2 §4.1)
  - transport: 1 confirmation -> 4 downstream appointments, each
    receiving 3 parent signals carrying source chi (P1 §4.2-4.3),
    realized as the face-adjacent forward FCC projection (approved).

LATTICE / LAYER MODEL (structural-sim form, per spec §0):
  We work confirmation-to-confirmation on a single FCC lattice. A "layer
  advance" T takes the current confirmed-chi field and produces the next
  confirmed-chi field by: for each site x that is an appointment in the
  next layer, gather its 3 parent signals (from the confirmed neighbours
  that project onto x), form Pi_psi, resolve chi(x). On a homogeneous FCC
  patch the natural concrete realization (approved §1c) is:

    parents(x) = the 3 lowest-index FCC nearest neighbours of x that are
                 confirmed in the current layer, with the tetrahedral
                 projection ensuring each confirmed site feeds 4 forward
                 appointments. For the structural closure tests we use the
                 symmetric majority-of-FCC-neighbourhood realization of the
                 signed aggregate: Pi_psi(x) = mean(chi over confirmed FCC
                 NN of x), which is the faithful continuum of the 3-parent
                 average when the neighbourhood is the tetrahedral shell.

  NOTE: the corpus's 3-parent rule and the FCC-neighbourhood mean coincide
  on the tetrahedral shell (3 mutual NN = a triangle feeding the centroid);
  we expose BOTH and let the caller pick `parent_mode='triad'` (strict
  3-parent) or `parent_mode='shell'` (full-neighbourhood mean). Default
  'triad' = the literal corpus rule.
"""
import itertools
import numpy as np


# ----------------------------------------------------------------------
# FCC geometry (storage convention: i+j+k even = level-0 agent sites)
# ----------------------------------------------------------------------
def fcc_nn_offsets():
    return [o for o in itertools.product((-1, 0, 1), repeat=3)
            if o[0]**2 + o[1]**2 + o[2]**2 == 2]


NN_OFFSETS = fcc_nn_offsets()  # 12 face-diagonal neighbours


def fcc_neighbors(site, site_set):
    i, j, k = site
    return [(i+di, j+dj, k+dk) for (di, dj, dk) in NN_OFFSETS
            if (i+di, j+dj, k+dk) in site_set]


# ----------------------------------------------------------------------
# Resolution (both branches)
# ----------------------------------------------------------------------
def resolve(pi, branch, rng):
    if branch == "deterministic":
        if pi > 0:
            return 1
        if pi < 0:
            return -1
        return int(rng.choice([-1, 1]))
    elif branch == "probabilistic":
        return 1 if rng.random() < (1 + pi) / 2 else -1
    raise ValueError(branch)


# ----------------------------------------------------------------------
# One flop T on a confirmed-chi field over an FCC patch
# chi: dict site -> {-1,+1} (confirmed sites only; missing = unconfirmed)
# ----------------------------------------------------------------------
def flop(chi, sites, site_set, nbr_map, branch="deterministic",
         parent_mode="triad", rng=None):
    if rng is None:
        rng = np.random.default_rng()
    new = {}
    for x in sites:
        nbrs = nbr_map[x]
        confirmed = [chi[n] for n in nbrs if n in chi]
        if not confirmed:
            # no parents -> remains unconfirmed (no appointment resolved)
            continue
        if parent_mode == "triad":
            # strict corpus rule: 3 parent signals. Take up to 3 confirmed
            # neighbours (the confirming triangle); if fewer than 3 are
            # confirmed the appointment is not yet actualizable -> skip.
            if len(confirmed) < 3:
                continue
            parents = confirmed[:3]
            pi = sum(parents) / 3.0
        else:  # 'shell' : signed aggregate over full confirmed neighbourhood
            pi = sum(confirmed) / len(confirmed)
        new[x] = resolve(pi, branch, rng)
    return new


def iterate_T(chi0, sites, site_set, nbr_map, n, **kw):
    chi = dict(chi0)
    history = [dict(chi)]
    for _ in range(n):
        chi = flop(chi, sites, site_set, nbr_map, **kw)
        history.append(dict(chi))
    return history


# ----------------------------------------------------------------------
# Equality up to lattice translation (for T-closure on a torus)
# ----------------------------------------------------------------------
def pattern_signature(chi, sites):
    """Canonical form of a confirmed-chi pattern, translation-normalized:
    shift so the min-corner of the confirmed support is at origin."""
    pts = [s for s in sites if s in chi]
    if not pts:
        return frozenset()
    mn = (min(p[0] for p in pts), min(p[1] for p in pts), min(p[2] for p in pts))
    return frozenset(((p[0]-mn[0], p[1]-mn[1], p[2]-mn[2]), chi[p]) for p in pts)


def equal_up_to_translation(chiA, chiB, sites):
    return pattern_signature(chiA, sites) == pattern_signature(chiB, sites)


if __name__ == "__main__":
    # smoke test: T runs and signal accounting is sane on a small patch
    np.set_printoptions(legacy="1.25")
    L = 7
    sites = [(i, j, k) for i in range(L) for j in range(L) for k in range(L)
             if (i+j+k) % 2 == 0]
    ss = set(sites)
    nbr = {s: fcc_neighbors(s, ss) for s in sites}
    rng = np.random.default_rng(0)

    # start: confirm a random half the sites
    chi0 = {s: int(rng.choice([-1, 1])) for s in sites if rng.random() < 0.5}
    print(f"FCC patch L={L}: {len(sites)} sites, {len(chi0)} confirmed at t=0")

    for branch in ("deterministic", "probabilistic"):
        hist = iterate_T(chi0, sites, ss, nbr, n=3, branch=branch,
                         parent_mode="triad", rng=np.random.default_rng(1))
        sizes = [len(h) for h in hist]
        print(f"  {branch:>14}: confirmed-count per flop = {sizes}")

    print("\nT module loaded and self-consistent.")
